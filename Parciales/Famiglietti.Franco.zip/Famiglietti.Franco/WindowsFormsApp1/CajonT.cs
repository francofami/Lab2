﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SP
{
    public class Cajon<T>
    {
        protected int _capacidad;
        protected List<T> _elementos;
        protected double _precioUnitario;

        public EventoPrecio delegado;

        void EventoPrecio(Object obj, EventArgs args)
        {
            MessageBox.Show("Se superaron los 55 pesos");

            try
            {
                StreamWriter sw;
                sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\superoPrecio.txt", false);
                sw.WriteLine(System.DateTime.Now.ToString() + "Total : " + this.PrecioTotal.ToString());
                sw.Close();
            }

            catch (Exception e)
            {
            }

        }

        public List<T> Elementos
        {
            get
            {
                return this._elementos;
            }
        }

        public double PrecioTotal
        {
            get
            {
                return this._precioUnitario * this._elementos.Count;
            }
        }

        public Cajon()
        {
            this._elementos = new List<T>();
        }

        public Cajon(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }

        public Cajon(double precioUnitario, int capacidad) : this(capacidad)
        {
            this._precioUnitario = precioUnitario;
        }

        public string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Capacidad " + this._capacidad);
            retorno.AppendLine("Cantidad total: " + this._elementos.Count);
            if(this.PrecioTotal > 55)
            {
                this.delegado.Invoke("");
                //new EventHandler(EventoPrecio);
            }
            retorno.AppendLine("Precio total: " + this.PrecioTotal);
            retorno.AppendLine("Lista de elementos: ");

            foreach (T te in this.Elementos)
            {
                retorno.AppendLine("" + te);
            }

            return retorno.ToString();
        }

        public static Cajon<T> operator +(Cajon<T> cajon, T item)
        {
            try
            {
                if (!(cajon._elementos.Count < cajon._capacidad))
                {
                    throw new CajonLlenoException();
                }
                else
                {
                    cajon._elementos.Add(item);
                }
            }
            catch(Exception e)
            {
                
            }              

            return cajon;
        }


    }
}
