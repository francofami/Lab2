﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SP
{
    public class Manzana : Fruta
    {
        protected string provinciaOrigen;
        string nombre;

        public override bool TieneCarozo
        {
            get
            {
                return true;
            }
        }

        public Manzana(string color, double peso, string provincia) : base(color, peso)
        {
            this.provinciaOrigen = provincia;
        }

        public string Nombre
        {
            get
            {
                return "Manzana";
            }
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Fruta: " + this.Nombre);
            retorno.AppendLine("Provincia origen: " + this.provinciaOrigen);
            retorno.AppendLine(base.FrutaToString());

            return retorno.ToString();
        }
    }
}
