﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SP
{
    public abstract class Fruta
    {
        protected string _color;
        protected double _peso;
        bool _tieneCarozo;

        public abstract bool TieneCarozo
        {
            get;
        }

        public Fruta(string color, double peso)
        {
            this._color = color;
            this._peso = peso;
        }

        protected virtual string FrutaToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Color: " + this._color);
            retorno.AppendLine("Peso: " + this._peso);
            retorno.AppendLine("Tiene carozo: " + this.TieneCarozo);

            return retorno.ToString();
        }
    }
}
