﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SP
{
    public class Durazno : Fruta
    {
        protected int _cantPelusa;
        public string nombre;

        public override bool TieneCarozo
        {
            get
            {
                return true;
            }
        }

        public Durazno(string color, double peso, int cantPelusa) : base(color, peso)
        {
            this._cantPelusa = cantPelusa;
        }

        public string Nombre
        {
            get
            {
                return "Durazno";
            }
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Fruta: " + this.Nombre);
            retorno.AppendLine("Cant. pelusa: " + this._cantPelusa);
            retorno.AppendLine(base.FrutaToString());

            return retorno.ToString();
        }


    }
}
