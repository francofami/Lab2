﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SP
{
    public class Banana : Fruta
    {
        protected string _paisOrigen;
        public string nombre;

        public override bool TieneCarozo
        {
            get
            {
                return false;
            }
        }

        public Banana(string color, double peso, string pais) : base(color, peso)
        {
            this._paisOrigen = pais;
        }

        public string Nombre
        {
            get
            {
                return "Banana";
            }
        }

        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Fruta: " + this.Nombre);
            retorno.AppendLine("Pais origen: " + this._paisOrigen);
            retorno.AppendLine(base.FrutaToString());

            return retorno.ToString();
        }
    }
}
