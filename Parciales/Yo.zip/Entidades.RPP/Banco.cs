﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public class Banco
    {

        public string nombre;

        public Banco(string nombre)
        {
            this.nombre = nombre;
        }

        public string Mostrar()
        {
            string retorno = "";

            retorno += "Nombre: ";

            retorno += this.nombre;

            retorno += "\n";

            return retorno;
        }

        public string Mostrar(Banco ban)
        {
            string retorno = "";
            int flag = 0;

            retorno += this.Mostrar();

            if (ban is BancoMunicipal)
            {
                retorno += "Municipio: ";
                retorno += ((BancoMunicipal)ban).municipio;
                retorno += "\n";
                flag = 1;
            }

            if (ban is BancoProvincial || flag == 1)
            {
                retorno += "Provincia: ";
                retorno += ((BancoProvincial)ban).provincia;
                retorno += "\n";
                flag = 2;
            }

            if (ban is BancoNacional || flag ==2)
            {
                retorno += "Pais: ";
                retorno += ((BancoNacional)ban).pais;
                retorno += "\n";
            }
            
            return retorno;
        }
    }
}
