﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public class Deposito
    {
        public Producto[] productos;

        public Deposito()
        {
            this.productos = new Producto[3];
        }

        public Deposito(int cantidadProductos)
        {
            this.productos = new Producto[cantidadProductos];
        }

        public static Producto[] operator +(Deposito d1, Deposito d2)
        {
            Producto[] retorno;
            retorno = new Producto[d1.productos.Length+d2.productos.Length];
            int indice = 0;
            int flag = 0;

            foreach (Producto pdt1 in d1.productos)
            {
                foreach(Producto pdt2 in d2.productos)
                {
                    if(pdt1 == pdt2)
                    {
                        Producto aux;
                        aux = new Producto(pdt1.nombre, pdt1.stock+pdt2.stock);

                        for (int i = 0; i < retorno.Length; i++)
                        {
                            if (retorno[i] == null)
                            {
                                retorno[indice] = aux;
                                break;
                            }

                        }

                        flag = 1;
                        break;           
                    }

                }

                if(flag == 0)
                {
                    for(int i=0; i<retorno.Length;i++)
                    {
                        if(retorno[i] == null)
                        {
                            retorno[indice] = pdt1;
                            break;
                        }

                    }

                    flag = 0;
                }

                indice++;
            }

            flag = 0;

            foreach (Producto pdt2 in d2.productos)
            {
                foreach (Producto pdt1 in d1.productos)
                {
                    if (pdt1 == pdt2)
                    {
                        flag = 1;
                        break;
                    }

                }

                if (flag == 0)
                {
                    for (int i = 0; i < retorno.Length; i++)
                    {
                        if (retorno[i] == null)
                        {
                            retorno[indice] = pdt2;
                            break;
                        }

                    }

                    flag = 0;
                }

                indice++;
            }

            return retorno;
        }
    }
}
