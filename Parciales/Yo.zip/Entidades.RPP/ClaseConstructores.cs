﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Entidades.RPP
{
    public class ClaseConstructores
    {
        private int var1;
        private string var2;
        static int var3;

        static ClaseConstructores()
        {
            var3 = 0;

            ClaseConstructores dd = new ClaseConstructores(2, "fdf");

            MessageBox.Show("Paso por constructor estatico");
        }

        private ClaseConstructores(int var1, string var2) : this()
        {
            this.Var1 = var1;
            this.var2 = Var2;

            MessageBox.Show("Paso por constructor privado");
        }

        public ClaseConstructores()
        {
            this.var1 = 5;
            this.var2 = "Hola";

            MessageBox.Show("Paso por constructor publico");
        }

        public int Var1
        {
            set
            {
                MessageBox.Show("Paso por Propiedad escritura");
                this.var1 = value;
                Metodo();
            }           
        }

        public string Var2
        {
            get
            {
                MessageBox.Show("Paso por Propiedad lectura");
                return this.var2;
                Metodo2();
            }
        }

        public void Metodo()
        {
            MessageBox.Show("Paso por Metodo");
        }

        static void Metodo2()
        {
            MessageBox.Show("Paso por Mtodo estatico");
        }
    }
}
