﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
    public class BancoMunicipal : BancoProvincial
    {
        public string municipio;
        public BancoProvincial bp;

        public BancoMunicipal(BancoProvincial bp, string municipio) : base(bp.bn, bp.provincia)
        {
            this.municipio = municipio;
            this.bp = new BancoProvincial(bp.bn, bp.provincia);
        }

        public string ToString()
        {
            string retorno = "";

            retorno = "Nombre: " + this.nombre + "Municipio: " + this.municipio + "\n" + "Provincia: " + this.provincia + "\n" + "Pais: " + this.pais;

            return retorno;
        }

        public static implicit operator string(BancoMunicipal ban)
        {
            return ban.ToString();
        }
    }
}
