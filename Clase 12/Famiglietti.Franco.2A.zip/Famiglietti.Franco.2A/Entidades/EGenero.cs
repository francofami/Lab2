﻿public enum EGenero
{
    Accion, CienciaFiccion, Romantica
}