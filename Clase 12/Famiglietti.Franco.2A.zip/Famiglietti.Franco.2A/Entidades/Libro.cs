﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Libro
    {
        protected Autor _autor;
        protected int _cantidadDePaginas;
        protected Random _generadorDePaginas;
        protected float _precio;
        protected string _titulo;

        public int CantidadDePaginas
        {
            get
            {
                _generadorDePaginas = new Random();

                if(this._cantidadDePaginas==0)
                {
                    this._cantidadDePaginas = _generadorDePaginas.Next(10, 580);
                }

                return this._cantidadDePaginas;
            }
        }

        private Libro()
        {
            this._autor.apellido = "Kafka";
            this._autor.nombre = "Franz";
            this._titulo = "La metamorfosis";
            this._precio = 100;
            this._cantidadDePaginas = CantidadDePaginas;
        }

        protected Libro(float precio, string titulo, string nombre, string apellido)
        {
            Autor aut = new Autor(nombre,apellido);
            this._precio = precio;
            this._titulo = titulo;
        }

        protected Libro(string titulo, Autor autor, float precio) 
        {
            this._titulo = titulo;

            this._autor = autor;

            this._precio = precio;
            
        }

        protected virtual string Mostrar(Libro l)
        {
            string retorno = "";

            retorno = "\nAutor: " + l._autor.apellido + l._autor.nombre + "\nCantidad de paginas: " + l._cantidadDePaginas;
            retorno = "\nPrecio: " + l._precio + "\nTitulo: " + l._titulo;

            return retorno;
        }

        public static bool operator ==(Libro a, Libro b)
        {
            bool retorno = false;

            if(a._autor==b._autor && a._titulo==b._titulo)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Libro a, Libro b)
        {
            return !(a == b);
        }

    }
}
