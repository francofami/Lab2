﻿public enum ELibro
{
    Ambos, Manual, Novela
}