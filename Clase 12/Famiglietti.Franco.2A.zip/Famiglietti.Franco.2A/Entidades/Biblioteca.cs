﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biblioteca
    {
        protected int _capacidad;
        protected List<Libro> _libros;

        public double PrecioDeManuales
        {
            get
            {
                double retorno = 0;

                retorno = ObtenerPrecio(ELibro.Manual);

                return retorno;
            }
        }

        public double PrecioDeNovelas
        {
            get
            {
                double retorno = 0;

                retorno = ObtenerPrecio(ELibro.Novela);

                return retorno;
            }
        }

        public double PrecioTotal
        {
            get
            {
                double retorno = 0;

                retorno = ObtenerPrecio(ELibro.Ambos);

                return retorno;
            }
        }

        protected Biblioteca()
        {
            this._libros = new List<Libro>();
        }

        protected Biblioteca(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }

        public static implicit operator Biblioteca(int capacidad)
        {
            Biblioteca retorno;

            retorno = new Biblioteca();

            foreach (Libro lib in retorno._libros)
            {
                if (lib.CantidadDePaginas == capacidad)
                {
                    retorno = new Biblioteca(capacidad);
                }
            }

            return retorno;
        }

        public static string Mostrar(Biblioteca e)
        {
            string retorno = "";

            foreach(Libro lib in e._libros)
            {
                retorno += lib.ToString();
            }

            return retorno;
        }

        protected double ObtenerPrecio(ELibro tipolibro)
        {
            double retorno = 0;

            foreach (Libro item in this._libros)
            {
                switch (tipolibro)
                {
                    case ELibro.Manual:
                        if (item is Manual)
                        {
                            retorno += PrecioDeManuales;
                        }
                        break;
                    case ELibro.Novela:
                        if (item is Novela)
                        {
                            retorno += PrecioDeNovelas;
                        }
                        break;
                    case ELibro.Ambos:
                        if (item is Manual && item is Novela)
                        {
                            retorno += PrecioDeNovelas;
                            retorno += PrecioDeManuales;
                        }
                        break;

                }
            }

            return retorno;
        }

        public static bool operator ==(Biblioteca e, Libro l)
        {
            bool retorno = false;

            foreach(Libro lib in e._libros)
            {
                if(l == lib)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Biblioteca e, Libro l)
        {
            return !(e == l);
        }

        public static Biblioteca operator +(Biblioteca e, Libro l)
        {
            Biblioteca retorno = e;
            bool existeLibro = false;

            foreach(Libro lib in e._libros)
            {
                if(lib==l)
                {
                    existeLibro = true;
                }
            }

            if(e._capacidad>e._libros.Count && existeLibro == false)
            {
                retorno += l;
            }

            return retorno;
        }
    }
}
