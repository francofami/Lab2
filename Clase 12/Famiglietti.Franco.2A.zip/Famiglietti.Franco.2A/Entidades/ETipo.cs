﻿public enum ETipo
{
    Escolar, Finanzas, Tecnico
}