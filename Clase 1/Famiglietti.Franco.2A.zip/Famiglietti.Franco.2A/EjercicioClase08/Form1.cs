﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesClase07; //Tengo que agregar esto para que me reconozca las referencias que agregué

namespace EjercicioClase08
{
    public partial class Form1 : Form
    {
        Paleta _miPaleta;

        public Form1()
        {
            InitializeComponent();
            this.groupBox1.Text = "Paleta de colores";
            this.textBox1.Multiline = true;
            this.button1.Text = "+";
            this.button2.Text = "-";
            this.textBox1.Multiline = true; //Me permite ensanchar el cuadro
            

            _miPaleta = 5;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FRMTempera frm = new FRMTempera();
            DialogResult rta = frm.ShowDialog();

            if(rta == DialogResult.OK)
            {
                this._miPaleta += frm.MiTempera;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            //this.agregarPaletaToolStripMenuItem.Enabled = false; //Hace que no pueda elegir la opcion Agregar Paleta
        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.groupBox1.Visible = true; //Hace que al hacer clic al agregar paleta pueda ver el groupbox que cree
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
