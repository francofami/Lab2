﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesClase07; //Tengo que agregar esto para que me reconozca las referencias que agregué

namespace EjercicioClase08
{
    public partial class Form1 : Form
    {
        PaletaColeccion _miPaleta;

        public Form1()
        {
            InitializeComponent();

            _miPaleta = 5;

            this.groupBox1.Text = "Paleta de colores";
            this.button1.Text = "+";
            this.button2.Text = "-";
            this.textBox1.Multiline = true; //Me permite ensanchar el cuadro
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FRMTempera frm;

            int indice = ObtenerIndiceSeleccionado();

            if (indice >= 0 && this.textBox1.SelectedText.Length > 0)
            {
                frm = new FRMTempera(_miPaleta[indice]);
            }
            else
                frm = new FRMTempera();

            DialogResult rta = frm.ShowDialog();

            if(rta == DialogResult.OK)
            {
                this._miPaleta += frm.MiTempera;
                this.textBox1.Text = (string)this._miPaleta;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int indice = ObtenerIndiceSeleccionado();

            /*FRMTempera frm = new FRMTempera();
            DialogResult rta = frm.ShowDialog();

            if (rta == DialogResult.OK)
            {
                this._miPaleta -= frm.MiTempera;
                this.textBox1.Text = "";
            }*/ //Esto hacce que tenga que poner color, cantidad y marca para eliminar tempera

            /*texto = this.textBox1.SelectedText;
            
            foreach(string item in this.textBox1.Lines)
            {
                if(texto == item)
                {
                    break;
                }

                indice++;
            }

            //indice = (indice - 2) / 2;

            texto += " Indice: ";
            texto += indice.ToString();

            MessageBox.Show(texto);*/ //Esto hace que tenga que selecionar una tempera para eliminarla

            FRMTempera fortemp;

            if (indice >= 0 && this.textBox1.SelectedText.Length > 0)
            {
                fortemp = new FRMTempera(_miPaleta[indice]);
            }
            else
                fortemp = new FRMTempera();

            DialogResult rta = fortemp.ShowDialog();

            if (rta == DialogResult.OK)
            {
                this._miPaleta -= fortemp.MiTempera;
                this.textBox1.Text = (string)_miPaleta;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            //this.agregarPaletaToolStripMenuItem.Enabled = false; //Hace que no pueda elegir la opcion Agregar Paleta
        }

        private void agregarPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.groupBox1.Visible = true; //Hace que al hacer clic al agregar paleta pueda ver el groupbox que cree
            this.agregarPaletaToolStripMenuItem.Enabled = false;
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private int ObtenerIndiceSeleccionado()
        {
            int retorno = -1;

            foreach (string item in this.textBox1.Lines) 
            {                                            
                if (this.textBox1.SelectedText == item) 
                    break;
                retorno++;
            }

            return retorno;
        }
    }
}
