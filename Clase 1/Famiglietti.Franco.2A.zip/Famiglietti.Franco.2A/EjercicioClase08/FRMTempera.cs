﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesClase07;

namespace EjercicioClase08
{
    public partial class FRMTempera : Form
    {
        private Tempera _miTempera;

        public Tempera MiTempera { get{ return this._miTempera; } }

        public FRMTempera()
        {
            InitializeComponent();

            this.label1.Text = "Color";
            this.label2.Text = "Marca";
            this.label3.Text = "Cantidad";

            foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
            {
                this.cboColor.Items.Add(color);
            }

            this.cboColor.SelectedItem = ConsoleColor.Black; //Aca asigno un color por defecto
            this.cboColor.DropDownStyle = ComboBoxStyle.DropDownList; //Para que el usuario no pueda editar las opciones, solo seleccionar una opcion
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cboColor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FRMTempera_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            sbyte cantidad;
            ConsoleColor color;
            string marca;

            cantidad = sbyte.Parse(this.textBox2.Text); // Uso el .Parse porque es numerico

            color = (ConsoleColor) this.cboColor.SelectedItem;

            marca = this.textBox1.Text;

            this._miTempera = new Tempera(cantidad, color, marca);

            this.DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public FRMTempera(Tempera obj1) : this()
        {
            /*InitializeComponent();

            foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
            {
                this.cboColor.Items.Add(color);
            }

            this.cboColor.SelectedItem = ConsoleColor.Black; //Aca asigno un color por defecto
            this.cboColor.DropDownStyle = ComboBoxStyle.DropDownList; //Para que el usuario no pueda editar las opciones, solo seleccionar una opcion
            this._miTempera = obj1;*/
        }
    }
}
