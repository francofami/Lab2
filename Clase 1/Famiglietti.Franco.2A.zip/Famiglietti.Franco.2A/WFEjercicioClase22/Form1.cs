﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFEjercicioClase22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void MiManejadorClick(Object obj, EventArgs args)
        {
            MessageBox.Show(((Control)obj).Name); //Muestra el nombre del controlador que lo provocó
        }

        void MiOtroManejadorClick(Object obj, EventArgs args)
        {
            this.button2.Click -= new EventHandler(MiManejadorClick);
            this.button1.Click += new EventHandler(MiManejadorClick);
        }

        void MiTercerManejadorClick(Object obj, EventArgs args)
        {
            if(obj.Equals(this.button1))
            {
                this.button1.Click -= new EventHandler(MiManejadorClick);
                this.button1.Click -= new EventHandler(MiTercerManejadorClick);
                this.button2.Click += new EventHandler(MiManejadorClick);
                this.button2.Click += new EventHandler(MiTercerManejadorClick);
            }
            else if(obj.Equals(this.button2))
            {
                this.button2.Click -= new EventHandler(MiManejadorClick);
                this.button2.Click -= new EventHandler(MiTercerManejadorClick);
                this.textBox1.Click += new EventHandler(MiManejadorClick);
                this.textBox1.Click += new EventHandler(MiTercerManejadorClick);
            }
            else if(obj.Equals(this.textBox1))
            {
                this.textBox1.Click -= new EventHandler(MiManejadorClick);
                this.textBox1.Click -= new EventHandler(MiTercerManejadorClick);
                this.button1.Click += new EventHandler(MiManejadorClick);
                this.button1.Click += new EventHandler(MiTercerManejadorClick);
            }
        }

        void CambiarFondo(Object obj, EventArgs args)
        {
            (((Control)obj).BackColor) = Color.Cyan; //Pinta el controlador que lo llamó
            this.button2.Click += new EventHandler(MiManejadorClick);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*this.button1.Click += new EventHandler(MiManejadorClick);
            this.button2.Click += new EventHandler(MiManejadorClick);
            this.textBox1.Click += new EventHandler(MiManejadorClick);
            this.Click += new EventHandler(MiOtroManejadorClick);
            this.button2.Click += new EventHandler(CambiarFondo);*/
     
            this.button1.Click += new EventHandler(MiTercerManejadorClick);
            this.button1.Click += new EventHandler(MiManejadorClick);
        }   

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e) //Quita los eventos de los botones que cree en Load
        {
            this.button1.Click -= new EventHandler(MiManejadorClick);
            this.button2.Click -= new EventHandler(MiManejadorClick);
            this.textBox1.Click -= new EventHandler(MiManejadorClick);
            this.Click -= new EventHandler(MiOtroManejadorClick);
            this.button2.Click -= new EventHandler(CambiarFondo);
        }
    }
}
