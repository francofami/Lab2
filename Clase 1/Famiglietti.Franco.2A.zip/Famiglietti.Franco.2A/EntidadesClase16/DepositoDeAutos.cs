﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;

        public bool Agregar(Auto a)
        {
            bool retorno = false;

            retorno = this + a;

            return retorno;
        }

        public DepositoDeAutos(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Auto>();
        }

        private int GetIndice(Auto a)
        {
            int retorno = -1;

            int indice = 0;

            foreach (Auto autito in this._lista)
            {
                if(autito == a)
                {
                    retorno = indice;
                    break;
                }

                indice++;
            }

            return retorno;
        }

        public static bool operator +(DepositoDeAutos d, Auto b)
        {
            bool retorno = false;

            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(b);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator -(DepositoDeAutos d, Auto b)
        {
            bool retorno = false;

            int indice = d.GetIndice(b);

            if(indice >= 0)
            {
                d._lista.RemoveAt(indice);
                retorno = true;
            }

            return retorno;
        }

        public bool Remover(Auto a)
        {
            bool retorno = false;

            retorno = this - a;

            return retorno;
        }

        public override string ToString()
        {
            string retorno = "";

            retorno = "\nCapacidad Maxima : " + this._capacidadMaxima;

            foreach(Auto autito in this._lista)
            {
                retorno += "\n" + autito.ToString();
            }

            return retorno;
        }
    }
}
