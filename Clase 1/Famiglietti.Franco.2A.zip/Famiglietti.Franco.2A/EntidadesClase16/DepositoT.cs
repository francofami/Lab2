﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase16
{
    class Deposito<T>
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public bool Agregar(T a)
        {
            bool retorno=false;

            retorno = this + a;

            return retorno;
        }

        public Deposito(int capacidad)
        {
            this._capacidadMaxima = capacidad;
        }

        private int GetIndice(T a)
        {
            int retorno = -1;
            int indice = 0;

            foreach(T te in this._lista)
            {
                if(Object.Equals(te,a) == true)
                {
                    break;
                }

                indice++;
            }


            return retorno;
        }

        public static bool operator+(Deposito<T> d, T a)
        {
            bool retorno = false;

            if(d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(a);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator -(Deposito<T> d, T a)
        {
            bool retorno = false;

            int indice= d.GetIndice(a);

            if(d._capacidadMaxima >= 0)
            {
                d._lista.RemoveAt(indice);
                retorno = true;
            }

            return retorno;
        }

        public bool Remover(T a)
        {
            bool retorno = false;

            retorno = this - a;

            return retorno;
        }

        public string ToString()
        {
            string retorno = "";

            retorno = "\nCapacidad Maxima : " + this._capacidadMaxima;

            foreach (T te in this._lista)
            {
                retorno += "\n" + te.ToString();
            }

            return retorno;
        }
    }
}
