﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int j;
            bool esPrimo;

            Console.Write("Ingrese un numero: ");
            numero = int.Parse(Console.ReadLine());

            Console.WriteLine("Numeros primos: ");

            for(i=1;i<=numero;i++)
            {
                esPrimo = true;

                for(j=2; j<i; j++)
                {
                    if (i % j == 0)
                    {
                        esPrimo = false;
                        break;
                    }
                }

                if(esPrimo == true)
                Console.WriteLine("{0}", i);
            }

            Console.ReadLine();
        }
    }
}
