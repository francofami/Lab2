﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int primo;

            Console.Write("Ingrese un numero");
            numero = int.Console.ReadLine();

            for(i>numero;i<=1;i--)
            {
                if(numero %  == 0)
                {

                }

            }
        }
    }
}
