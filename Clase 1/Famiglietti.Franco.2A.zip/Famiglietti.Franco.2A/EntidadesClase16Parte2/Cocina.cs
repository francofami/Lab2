﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EntidadesClase16Parte2
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo
        {
            get
            {
                return this._codigo;
            }
        }

        public bool EsIndustrial
        {
            get
            {
                return this._esIndustrial;
            }
        }

        public double Precio
        {
            get
            {
                return this._precio;
            }
        }

        public Cocina(int codigo, double precio, bool esIndustrial)
        {
            this._codigo = codigo;
            this._precio = precio;
            this._esIndustrial = esIndustrial;
        }

        public bool Equals(object obj)
        {
            bool retorno = false;

            if(obj is Cocina)
            {
                Cocina cocinita = (Cocina) obj;

                if(cocinita._codigo == this._codigo)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator ==(Cocina a, Cocina b)
        {
            bool retorno = false;

            if(a._codigo == b._codigo)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Cocina a, Cocina b)
        {
            bool retorno = false;

            retorno = !(a==b);

            return retorno;
        }

        public string ToString()
        {
            string retorno = "";

            retorno += "\r\nCódigo: " + this._codigo.ToString() + "\r\nPrecio: " + this._precio.ToString() + "\r\nEs Industrial: " + this._esIndustrial.ToString();

            return retorno;
        }

        public bool Guardar(string path) //tuve que agregar using System.IO
        {
            bool retorno = false;

            StreamWriter sw;

            /* 
                Tambien podrñia hacer using(sw = new StreamWrite(p))
                {
                    sw.Write("..."=)
                }
                
            Y de esta forma no hace falta cerrar el archivo
             */

            sw = new StreamWriter(path, false); // True = sobreescribir, false = agregar 

            try
            {
                sw.WriteLine(this.ToString());
                sw.Close();
                retorno = true;

                return retorno;
            }

            catch (Exception e)
            {
                retorno = false;

                return retorno;
            }
        }

        public bool Recuperar(string path)
        {
            bool retorno = false;

            StreamReader sw;

            sw = new StreamReader(path, false);

            try
            {
                Console.WriteLine(sw.ReadToEnd());
                sw.Close();
                retorno = true;
                return retorno;
            }

            catch(Exception e)
            {
                retorno = false;

                return retorno;
            }
        }
    }
}
