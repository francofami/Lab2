﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Clase12;

namespace EjercicioClase12
{
    class Program
    {
        static void Main(string[] args)
        {
            Lavadero lav = new Lavadero("Autos a lavar");

            Vehiculo vehiculo1 = new Vehiculo("AAA-000", 4, EMarcas.Ford);
            Vehiculo vehiculo2 = new Vehiculo("AAA-001", 4, EMarcas.Scania);
            Vehiculo vehiculo3 = new Vehiculo("AAA-003", 4, EMarcas.Zanella);

            Auto auto = new Auto(vehiculo1.Patente, vehiculo1.Marca, 5);
            Camion camion = new Camion(vehiculo2.Patente, vehiculo2.Marca, 100230, 18);
            Moto moto = new Moto(vehiculo3.Patente, vehiculo3.Marca, 110, vehiculo3.CantRuedas);
            
            lav += auto;
            lav += camion;
            lav += moto;

            Console.Write("\n\tTotal Facturado: {0}\n", lav.MostrarTotalFacturado());
            Console.Write(lav.LavaderoToString);

            Console.ReadKey();
        }
    }
}
