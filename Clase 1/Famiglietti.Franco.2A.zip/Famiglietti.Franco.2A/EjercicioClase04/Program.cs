﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase04
{
    class Program
    {
        static void Main(string[] args)
        {
            Cosa datos = new Cosa();

            datos.cadena = "Hola";
            datos.numero = 1010;
            datos.fecha = DateTime.Now;

            Console.WriteLine(Cosa.Mostrar(datos));

            DateTime fecha = new DateTime(2003, 01, 01);

            Cosa obj1 = new Cosa();
            Cosa obj2 = new Cosa("Hola Mundo");
            Cosa obj3 = new Cosa("Hola", 10.2);
            Cosa obj4 = new Cosa("Chau Mundo", 11.4, fecha);

            Console.WriteLine(Cosa.Mostrar(obj1));
            Console.WriteLine(Cosa.Mostrar(obj2));
            Console.WriteLine(Cosa.Mostrar(obj3));
            Console.WriteLine(Cosa.Mostrar(obj4));

            Console.ReadLine();
        }
    }
}
