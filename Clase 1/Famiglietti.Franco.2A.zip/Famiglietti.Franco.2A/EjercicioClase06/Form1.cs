using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioClase06
{
  public partial class Form1 : Form
  {
    private EjercicioClase05.Pluma _pluma; //Tengo que poner el nombre del namespace antes
    private EjercicioClase05.Tinta _tinta;

    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      AdmTinta form = new AdmTinta();
      form.Show();
    }

    private void plumaToolStripMenuItem_Click(object sender, EventArgs e)
    {

    }
  }
}
