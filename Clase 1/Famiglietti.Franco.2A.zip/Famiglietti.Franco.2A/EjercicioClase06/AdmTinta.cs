using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioClase06
{
  public partial class AdmTinta : Form
  {
    public AdmTinta()
    {
      InitializeComponent();

      //Hago que me aparezcan las opciones en menu desplegable. Debo ponerlo en el constructor eso es mucho muy importante.
      foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.cboColor.Items.Add(color);
      }

      this.cboColor.SelectedItem = ConsoleColor.Black; //Aca asigno un color por defecto

      foreach (ETipoTinta tipoTinta in Enum.GetValues(typeof(ETipoTinta)))
      {
        this.cboTinta.Items.Add(tipoTinta);
      }

      this.cboTinta.SelectedItem = ETipoTinta.Comun;

      cboColor.DropDownStyle = ComboBoxStyle.DropDownList; //Esto se hace para que el usuario no pueda escribir en la lista

    }

    private void AdmTinta_Load(object sender, EventArgs e)
    {

    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
    {
      
    }

    private void textBox2_TextChanged(object sender, EventArgs e)
    {
      this.cboColor.Items.Add(ConsoleColor.Blue);

    }

    private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
    {
     
    }
  }
}
