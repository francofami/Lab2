using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
  class Pluma
  {
    private string _marca;
    private int _cantidad;
    private Tinta _tinta;

    public Pluma()
    {
      this._marca = "Sin Marca";
      this._cantidad = 0;
      this._tinta = null;
    }

    public Pluma(string marca) : this()
    {
      this._marca = marca;
    }

    public Pluma(string marca, int cantidad) : this(marca)
    {
      this._cantidad = cantidad;
    }

    public Pluma(string marca, int cantidad, Tinta tinta) : this(marca, cantidad)
    {
      this._tinta = tinta;
    }

    public static string MostrarPluma(Pluma parametro)
    {
      string retorno = "";

      retorno = parametro.MostrarPluma();

      return retorno;
    }

    private string MostrarPluma()
    {
      #region

      string retorno = "";

      retorno = this._cantidad.ToString();

      retorno += " - ";

      retorno += this._marca;

      retorno += " - ";

      retorno += Tinta.Mostrar(this._tinta);

      return retorno;

      #endregion
    }

    public static implicit operator string(Pluma obj)
    {
      string retorno;

      retorno = obj.MostrarPluma();

      return retorno;
    }

    public static bool operator ==(Pluma obj1, Tinta obj2)
    {
      bool retorno = false;

      if (obj1._tinta == obj2)
        retorno = true;

      return retorno;
    }

    public static bool operator !=(Pluma obj1, Tinta obj2)
    {
      return !(obj1._tinta == obj2);
    }

    public static Pluma operator +(Pluma obj1, Tinta obj2)
    {
      Pluma retorno;

      retorno = obj1;

      if (obj1 == obj2 && obj1._cantidad < 100 || obj1._tinta == null)
      {
        retorno._cantidad += 10;

        if (retorno._cantidad > 100)
        {
          retorno._cantidad = 100;
        }
      }

      return retorno;
    }

    public static Pluma operator -(Pluma obj1, Tinta obj2)
    {
      Pluma retorno;

      retorno = obj1;

      if (obj1 == obj2 && obj1._cantidad < 100 || obj1._tinta == null)
      {
        retorno._cantidad -= 25;

        if (retorno._cantidad < 0)
        {
          retorno._cantidad = 0;
        }
      }

      return retorno;
    }

  }
}
