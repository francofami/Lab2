﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase20;

namespace EjercicioClase21
{
    public class Program
    {
        static void Main(string[] args)
        {
            Televisor telev = new Televisor(5, "Phillips", 50000, 60, "Uzbekistán");
            Program programa = new Program();

            telev.MiEvento += new MiDelegado(Meto2); //Le paso la dirección de memoria al método vinculo al delegado con el main

            telev.MiEvento += new MiDelegado(programa.MetodoDelega2);

            telev.MiEvento += new MiDelegado(Meto2); //Le paso la dirección de memoria al método vinculo al delegado con el main

            telev.MiEvento += new MiDelegado(programa.MetodoDelega2);

            telev.MiEvento += new MiDelegado(Meto2); //Le paso la dirección de memoria al método vinculo al delegado con el main

            telev.MiEvento += new MiDelegado(programa.MetodoDelega2);

            telev.MiEvento += new MiDelegado(Meto2); //Le paso la dirección de memoria al método vinculo al delegado con el main

            telev.MiEvento += new MiDelegado(programa.MetodoDelega2);

            telev.Insertar();
            //Televisor.Borrar(telev);

            

            Console.ReadKey();
        }

        public static void Meto2()
        {
            Console.WriteLine("c inserto un registro en la DB");
        }

        public void MetodoDelega2()
        {
            Console.WriteLine("Estoy en el segundo metodo jojoooo");
        }
    }
}
