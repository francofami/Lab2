﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio08
{
    class Program
    {
        static void Main(string[] args)
        {
            float valorHora;
            string nombre;
            int antigüedad;
            int cantHoras;
            char continuar = 's';

            float total;
            float totalConAnt;
            float descuentos;
            float totalFinal;

            do
            {
                Console.WriteLine("Ingrese el nombre del empleado: ");
                nombre = Console.ReadLine();
                Console.WriteLine("Ingrese el valor por hora: ");
                valorHora = float.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese años de antigüedad");
                antigüedad = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese cantidad de horas trabajadas en el mes: ");
                cantHoras = int.Parse(Console.ReadLine());

                total = cantHoras * valorHora;
                totalConAnt = total + (antigüedad*150);
                descuentos = (13 * totalConAnt) / 100;
                totalFinal = totalConAnt - descuentos;

                Console.WriteLine("Nombre: {0}\nAntigüedad: {1} años\nValor Hora: {2}\nTotal a cobrar (bruto): {3}\nDescuentos: {4}\nTotal a cobrar (neto): {5} ",nombre,antigüedad,valorHora,totalConAnt, descuentos, totalFinal);

                Console.WriteLine("¿Desea seguir cargando empleados? s/n");
                continuar = char.Parse(Console.ReadLine());

            } while (continuar == 's');
        }
    }
}
