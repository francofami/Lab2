﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio05
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroFinal;

            Console.WriteLine("Ingrese hasta que numero quiere calcular centros numericos: ");
            numeroFinal = int.Parse(Console.ReadLine());


        }
    }
}
