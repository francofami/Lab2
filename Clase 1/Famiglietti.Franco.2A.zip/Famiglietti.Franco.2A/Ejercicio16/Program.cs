﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno alumnoUno = new Alumno("Hernandez", 1, "Javier");
            Alumno alumnoDos = new Alumno("Gonzales", 2, "Hector");
            Alumno alumnoTres = new Alumno("Gutierrez", 3, "Nestor");

            alumnoUno.Estudiar(5, 10);
            alumnoDos.Estudiar(3, 5);
            alumnoTres.Estudiar(1, 2);

            Console.WriteLine("Apellido\tNombre\tLegajo\tNota 1\tNota 2\tNota Final");
            Alumno.Mostrar(alumnoUno);
            Alumno.Mostrar(alumnoDos);
            Alumno.Mostrar(alumnoTres);

            Console.ReadLine();
        }
    }
}
