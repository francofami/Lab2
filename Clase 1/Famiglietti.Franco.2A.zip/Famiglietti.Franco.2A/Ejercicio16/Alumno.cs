﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    class Alumno
    {
        public static byte _nota1;
        public static byte _nota2;
        public static byte _nota3;
        public static string apellido;
        public static int legajo;
        public static string nombre;


    }
}
