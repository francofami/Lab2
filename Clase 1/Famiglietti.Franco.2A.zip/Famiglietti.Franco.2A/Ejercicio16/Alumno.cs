﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio16
{
    class Alumno
    {
        private byte _nota1;
        private byte _nota2;
        private byte _notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;

        public Alumno()
        {
            this.apellido = "";
            this.legajo = 0;
            this.nombre = "";
        }


        public Alumno(string apellido, int legajo, string nombre)
        {
            this.apellido = apellido;
            this.legajo = legajo;
            this.nombre = nombre;
        }

        public static void CalcularFinal()
        {
            Random rnd = new Random();

            Console.WriteLine(rnd.Next(1, 10).ToString());
        }

        public void Estudiar(byte notaUno, byte notaDos)
        {
            this._nota1 = notaUno;
            this._nota2 = notaDos;
        }

        public static void Mostrar(Alumno alumno)
        {
            Console.Write("{0}\t{1}\t{2}\t{3}\t{4}\t", alumno.apellido, alumno.nombre, alumno.legajo, alumno._nota1, alumno._nota2);
            if (alumno._nota1 >= 4 && alumno._nota2 >= 4)
            {
                CalcularFinal();
            }    
            else
            {
                Console.WriteLine("Alumno desaprobado");
            }
        }
    }
}
