﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio07
{
    class Program
    {
        static void Main(string[] args)
        {
            int diaNac;
            int mesNac;
            int añoNac;
            int diaAct;
            int mesAct;
            int añoAct;
            int dias;
            int meses;
            int años;
            int contadorBisiestos = 0;
            int i;
            int diasTotales;
            bool esBisiesto = false;

            Console.WriteLine("Ingrese dia de nacimiento: ");
            diaNac = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese mes de nacimiento: ");
            mesNac = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese año de nacimiento: ");
            añoNac = int.Parse(Console.ReadLine());

            diaAct = DateTime.Now.Day;
            mesAct = DateTime.Now.Month;
            añoAct = DateTime.Now.Year;

            años = añoAct - añoNac;
            meses = mesAct - mesNac;
            dias = diaAct - diaNac;

            for(i=añoNac;i<añoAct;i++)
            {
                esBisiesto = false;

                if (i % 4 == 0)
                {
                    esBisiesto = true;

                    if (i % 100 == 0)
                    {
                        esBisiesto = false;

                        if (i % 400 == 0)
                        {
                            esBisiesto = true;
                        }
                    }
                }

                if (esBisiesto == true)
                {
                    contadorBisiestos++;
                }
            }



            diasTotales = (años * 365) + contadorBisiestos + (meses * 30) + dias;

            Console.WriteLine("Llevas vivo {0} días.", diasTotales);

            Console.ReadLine();
        }
    }
}
