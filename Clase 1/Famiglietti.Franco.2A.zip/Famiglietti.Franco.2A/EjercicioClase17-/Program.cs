﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjercicioClase17;

namespace EjercicioClase17_
{
    class Program
    {
        static void Main(string[] args)
        {
            Deportivo depo1 = new Deportivo(1000000,"GG666",250);

            Console.WriteLine("Deportivo: ");
            Console.WriteLine("Impuesto AFIP: {0}", depo1.PropiedadL.ToString());
            Console.WriteLine("Impuesto ARBA: {0}", ((IARBA)depo1).PropiedadL.ToString());

            Avion avio1 = new Avion(100, 2000);

            Console.WriteLine("Avion: ");
            Console.WriteLine("Impuesto AFIP: {0}", avio1.PropiedadL.ToString());
            Console.WriteLine("Impuesto ARBA: {0}", ((IARBA)avio1).PropiedadL.ToString());

            Console.ReadLine();
        }
    }
}
