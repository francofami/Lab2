﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase07
{
    class Program
    {
        static void Main(string[] args)
        {
            Tempera temp1 = new Tempera(10, ConsoleColor.DarkCyan, "Pelikan");

             Console.Write(temp1); //Esto se puede mostrar asi gracias al implicit

            Console.ReadLine();
        }
    }
}
