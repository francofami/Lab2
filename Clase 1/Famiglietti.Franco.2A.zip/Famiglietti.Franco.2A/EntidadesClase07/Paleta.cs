﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesClase07
{
    class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaxElementos;

        public Paleta() : this(5)
        {

        }

        public Paleta(int cantidad)
        {
            this._cantMaxElementos = cantidad;
            this._colores = new Tempera[cantidad];
        }

        private string Mostrar()
        {
            string retorno = "";

            retorno += this._cantMaxElementos;

            foreach (Tempera item in this._colores)
            {
                retorno += " - ";
                retorno += item;
            }

            return retorno;
        }

        public static explicit operator string(Paleta obj)
        {
            string retorno;

            retorno = obj.Mostrar();

            return retorno;
        }

        public static implicit operator Paleta(int cant)
        {
            Paleta retorno;

            retorno = new Paleta(cant);

            return retorno;
        }

        public static bool operator ==(Paleta obj1, Tempera obj2)
        {
            int indice = 0;
            bool retorno = false;

            foreach (Tempera item in obj1._colores)
            {
                if (obj1._colores.GetValue(indice) != null) // Alternativa a Object.Equals(obj1, null)
                {
                    if (obj2 == item)
                    {
                        retorno = true;
                        break;
                    }
                }

                indice++;
            }

            return retorno;
        }

        public static bool operator !=(Paleta obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        public static Paleta operator +(Paleta obj1, Tempera obj2)
        {
            Paleta retorno;
            int indice;

            retorno = obj1;

            indice = obj1.ObtenerIndice(obj2);

            if (indice > -1)
            {
                obj2._colores[indice] += obj2;
            }
            else
            {
                indice = obj1.ObtenerIndice();

                if (indice > -1)
                {
                    obj2._colores[indice] = obj2;
                }
            }

            return retorno;
        }


        private int ObtenerIndice()
        {
           int retorno = -1;

           for (int i = 0; i < this._cantMaxElementos; i++)
           {
                if (this._colores.GetValue(i) != null)
                {
                    retorno = i;
                    break;
                }   
            }

            return retorno;
        }

        private int ObtenerIndice(Tempera obj)
        {
            int retorno = -1;

            for (int i = 0; i < this._cantMaximaElementos; i++)
            {
                if (this._colores[i] == obj)
                {
                    retorno = i;
                }
             }

            return retorno;
        }

    }

}