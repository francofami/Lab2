﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesClase07
{
    public class Paleta
    {

        private Tempera[] _colores;
        private int _cantMaxElementos;

        public Paleta() : this(5)
        {

        }

        public Paleta(int cantidad)
        {
            this._cantMaxElementos = cantidad;
            this._colores = new Tempera[this._cantMaxElementos];
        }

        private string Mostrar()
        {
            string retorno = "";

            foreach (Tempera item in this._colores)
            {
                retorno += item;
            }

            return retorno;
        }

        public static explicit operator string(Paleta obj)
        {
            string retorno="";

            if(obj != null)
            {
                retorno = obj.Mostrar();
            }

            return retorno;
        }

        public static implicit operator Paleta(int cant)
        {
            Paleta retorno;

            retorno = new Paleta(cant);

            return retorno;
        }

        public static bool operator ==(Paleta obj1, Tempera obj2)
        {
            int indice = 0;
            bool retorno = false;

            foreach (Tempera item in obj1._colores)
            {
                if (obj1._colores.GetValue(indice) != null) // Alternativa a Object.Equals(obj1, null)
                {
                    if (obj1._colores[indice] == obj2)
                    {
                        retorno = true;
                        break;
                    }
                }

                indice++;
            }

            return retorno;
        }

        public static bool operator !=(Paleta obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        public static Paleta operator +(Paleta obj1, Tempera obj2)
        {
            int indice=0;
            int indice2=0;

            indice = obj1.ObtenerIndice();
            indice2 = obj1.ObtenerIndice(obj2);

            if(obj1 == obj2)
            {
                if (indice==-1 && indice2 >=0)
                {
                    obj1._colores[indice2] += obj2;
                }
            }
            else
            {
                if (indice > -1)
                {
                    obj1._colores[indice] = obj2;
                }
            }

            return obj1;
        }

        public static Paleta operator -(Paleta obj1, Tempera obj2)
        {
            int indice=0;
            sbyte paletaInt;
            sbyte temperaInt;

            indice = obj1.ObtenerIndice(obj2); 

            if(obj1 == obj2)
            {
                if (indice >= 0)
                {
                    paletaInt = (sbyte)obj1._colores[indice];
                    temperaInt = (sbyte)obj2;

                    if (paletaInt - temperaInt <= 0)
                    {
                        obj1._colores[indice] = null;
                        //obj1._cantMaxElementos--;
                    }

                    else
                    {
                        obj1._colores[indice] += (sbyte) (temperaInt * (-1));//Aca tengo que usar += y multiplicar por -1 el otro parametro ya que en la clase tempera tengo sobrecarga de + entre tempera y sbyte pero no de -
                    }
                }
            }      

            return obj1;
        }


        private int ObtenerIndice()
        {
           int retorno = -1;

           for (int i = 0; i < this._cantMaxElementos; i++)
           {
                if ((object)this._colores[i] == null)
                {
                    retorno = i;
                    break;
                }   
            }

            return retorno;
        }

        private int ObtenerIndice(Tempera obj)
        {
            int retorno = -1;

            for (int i = 0; i < this._cantMaxElementos; i++)
            {
                if(this._colores.GetValue(i) != null)
                {
                    if (this._colores[i] == obj)
                    {
                        retorno = i;
                    }
                }              
             }

            return retorno;
        }

    }

}