﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase07 //Esto lo tuve que cambiar y poner el namespace de Class1
{
    public class Tempera
    {
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;

        public Tempera(sbyte cantidad, ConsoleColor color, string marca)
        {
            this._cantidad = cantidad;
            this._color = color;
            this._marca = marca;
        }

        public static implicit operator string(Tempera tempera)
        {
            string retorno="";

            if ((object)tempera != null)
            {
                retorno = tempera.Mostrar();
            }
            
            return retorno;
        }

        public static explicit operator sbyte(Tempera tempera)
        {
            sbyte retorno;

            retorno = tempera._cantidad;

            return retorno;
        }

        private string Mostrar()
        {
            string retorno = "";

            retorno += this._cantidad.ToString();

            retorno += " - ";

            retorno += this._color.ToString();

            retorno += " - ";

            retorno += this._marca;

            retorno += "\r\n";

            return retorno;
        }

        public static bool operator ==(Tempera obj1, Tempera obj2)
        {
            bool retorno = false;

            if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
            {
                if (obj1._color == obj2._color && obj1._marca == obj2._marca)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Tempera obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        public static Tempera operator +(Tempera tempera, sbyte cantidad)
        {
            Tempera temp = new Tempera(tempera._cantidad, tempera._color, tempera._marca);
            
            if(tempera._cantidad + cantidad <= 100)
            {
                tempera._cantidad += cantidad;
            }

            return tempera;
        }

        public static Tempera operator +(Tempera tempera1, Tempera tempera2)
        {
            Tempera retorno;

            if(tempera1 == tempera2 && tempera1._cantidad + tempera2._cantidad <=100)
            {
                tempera1._cantidad += tempera2._cantidad;
            }

            retorno = tempera1;

            return retorno;
        }
    }
}
