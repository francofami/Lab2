﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase07 //Esto lo tuve que cambiar y poner el namespace de Class1
{
    class Tempera
    {
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;

        public Tempera(sbyte cantidad, ConsoleColor color, string marca)
        {
            this._cantidad = cantidad;
            this._color = color;
            this._marca = marca;
        }

        public static implicit operator string(Tempera tempera)
        {
            string retorno;

            retorno = tempera.Mostrar();

            return retorno;
        }

        public static explicit operator sbyte(Tempera tempera)
        {
            sbyte retorno;

            retorno = tempera._cantidad;

            return retorno;
        }

        private string Mostrar()
        {
            string retorno = "";

            retorno += this._cantidad.ToString();

            retorno += " - ";

            retorno += this._color.ToString();

            retorno += " - ";

            retorno += this._marca;

            return retorno;
        }

        public static bool operator ==(Tempera obj1, Tempera obj2)
        {
            bool retorno = false;

            if(obj1==obj2)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Tempera obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        public static Tempera operator +(Tempera tempera, sbyte cantidad)
        {
            tempera._cantidad += cantidad;

            return tempera;
        }

        public static Tempera operator +(Tempera tempera1, Tempera tempera2)
        {
            Tempera retorno;

            if(tempera1 == tempera2)
            {
                tempera1._cantidad += tempera2._cantidad;
            }

            retorno = tempera1;

            return retorno;
        }
    }
}
