﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesClase07 //Esto lo tuve que cambiar y poner el namespace de Class1
{
    public class Tempera
    {
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;

        public sbyte Cantidad
        {
            get
            {
                return this._cantidad;
            }
        }

        public ConsoleColor Color
        {
            get
            {
                return this._color;
            }
        }

        public string Marca
        {
            get
            {
                return this._marca;
            }
        }

        /// <summary>
        /// Constructor de la clase Tempera
        /// </summary>
        /// <param name="cantidad"></param>
        /// <param name="color"></param>
        /// <param name="marca"></param>
        public Tempera(sbyte cantidad, ConsoleColor color, string marca)
        {
            this._cantidad = cantidad;
            this._color = color;
            this._marca = marca;
        }

        /// <summary>
        /// Devuelve la cantidad, color y marca de la tempera pasada como parámetro
        /// </summary>
        /// <param name="tempera"></param>
        public static implicit operator string(Tempera tempera)
        {
            string retorno="";

            if ((object)tempera != null)
            {
                retorno = tempera.Mostrar();
            }
            
            return retorno;
        }

        /// <summary>
        /// Devuelve la cantidad de la tempera pasada como parámetro
        /// </summary>
        /// <param name="tempera"></param>
        public static explicit operator sbyte(Tempera tempera)
        {
            sbyte retorno;

            retorno = tempera._cantidad;

            return retorno;
        }

        /// <summary>
        /// DEvuelve la cantidad, color y marca de la tempera
        /// </summary>
        /// <returns></returns>
        private string Mostrar()
        {
            string retorno = "";

            retorno += this._cantidad.ToString();

            retorno += " - ";

            retorno += this._color.ToString();

            retorno += " - ";

            retorno += this._marca;

            retorno += "\r\n";

            return retorno;
        }

        /// <summary>
        /// Si dos temperas son de igual color e igual marca entonces son iguales
        /// </summary>
        /// <param name="obj1"></param>
        /// <param name="obj2"></param>
        /// <returns></returns>
        public static bool operator ==(Tempera obj1, Tempera obj2)
        {
            bool retorno = false;

            if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
            {
                if (obj1._color == obj2._color && obj1._marca == obj2._marca)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Tempera obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        /// <summary>
        /// Suma cantidades a una tempera si es que no está llena.
        /// </summary>
        /// <param name="tempera"></param>
        /// <param name="cantidad"></param>
        /// <returns></returns>
        public static Tempera operator +(Tempera tempera, sbyte cantidad)
        {
            if (tempera._cantidad + cantidad <= 100)
            {
                tempera._cantidad += cantidad;
            }

            return tempera;
        }

        /// <summary>
        /// Suma las cantidades de dos temperas si es que las temperas son iguales
        /// </summary>
        /// <param name="tempera1"></param>
        /// <param name="tempera2"></param>
        /// <returns></returns>
        public static Tempera operator +(Tempera tempera1, Tempera tempera2)
        {
            Tempera retorno = new Tempera(tempera1._cantidad, tempera1._color, tempera1._marca);

            if (tempera1 == tempera2 && tempera1._cantidad + tempera2._cantidad <= 100)
            {
                tempera1._cantidad += tempera2._cantidad;
            }

            retorno = tempera1;

            return retorno;
        }
    }
}
