﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesClase07
{
    public class PaletaColeccion
    {
        List<Tempera> _colores = new List< Tempera >();
        private int _cantMaxElementos;

        public int CantMaximaElementos
        {
            get
            {
                return this._cantMaxElementos;
            }
        }

        public PaletaColeccion() : this(5)
        {

        }

        public PaletaColeccion(int cantidad)
        {
            this._cantMaxElementos = cantidad;
            //_colores.Add(new Tempera[this._cantMaxElementos]);
        }

        private string MostrarPaletaColeccion()
        {
            string retorno = "Cantidad maxima: " + this._cantMaxElementos + "\r\n";

            int cantidadElementos = this._colores.Count;

            for (int i = 0; i < cantidadElementos; i++)
            {
                retorno += this._colores[i];
            }
            return retorno;
        }

        public static explicit operator string(PaletaColeccion obj)
        {
            string retorno="";

            if(!Object.Equals(obj,null))
            {
                retorno = obj.MostrarPaletaColeccion();
            }

            return retorno;
        }

        public static implicit operator PaletaColeccion(int cant)
        {
            PaletaColeccion retorno;

            retorno = new PaletaColeccion(cant);

            return retorno;
        }

        public static bool operator ==(PaletaColeccion obj1, Tempera obj2)
        {
            bool retorno = false;
            int indice = 0;
            
            foreach (Tempera item in obj1._colores)
            {
                if (!Object.Equals(obj1, null))
                {
                    if (obj1._colores[indice] == obj2)
                    {
                        retorno = true;
                        break;
                    }
                }

                indice++;
            }

            return retorno;
        }

        public static bool operator !=(PaletaColeccion obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        public static int operator ==(Tempera obj1, PaletaColeccion obj2)
        {
            int retorno = -1;
            int indice = 0;

            for (indice = 0; indice < obj2._colores.Count; indice++)
            {
                if (!Object.Equals(obj1, null))
                {
                    if (obj2._colores[indice] == obj1)
                    {
                        retorno = indice;
                        break;
                    }
                }

                indice++;
            }

            return retorno;
        }


        public static int operator !=(Tempera obj1, PaletaColeccion obj2)
        {
            return obj1 == obj2;
        }


        public static PaletaColeccion operator +(PaletaColeccion obj1, Tempera obj2)
        {
            int indice = obj2 == obj1;
            if (indice > -1)
            {
                obj1._colores[indice] += obj2;
            }
            else
            {
                if (obj1._colores.Count < obj1._cantMaxElementos)
                {
                    obj1._colores.Add(obj2);
                }
            }
            return obj1;
        }

        public static PaletaColeccion operator -(PaletaColeccion obj1, Tempera obj2)
        {
            int indice = obj2 == obj1;
            if (indice > -1)
            {
                if ((sbyte)obj1._colores[indice] - (sbyte)obj2 < 1)
                    obj1._colores.RemoveAt(indice);
                else
                    obj1._colores[indice] += (sbyte)((sbyte)obj2 * -1);
            }
            return obj1;
        }

        public Tempera this[int indice]
        {
            get
            {
                if (indice >= this.CantMaximaElementos || indice < 0)
                    return null;
                else
                    return this._colores[indice];
            }
        }
    }
}