﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesClase07
{
    public class PaletaColeccion
    {
        List<Tempera> _colores = new List< Tempera >();
        private int _cantMaxElementos;

        public PaletaColeccion() : this(5)
        {

        }

        public PaletaColeccion(int cantidad)
        {
            this._cantMaxElementos = cantidad;
            _colores.Add(new Tempera[this._cantMaxElementos]);
        }

        private string MostrarPaletaColeccion()
        {
            string retorno = "";

            foreach (Tempera item in this._colores)
            {
                retorno += item;
            }

            return retorno;
        }

        public static explicit operator string(PaletaColeccion obj)
        {
            string retorno="";

            if(obj != null)
            {
                retorno = obj.MostrarPaletaColeccion();
            }

            return retorno;
        }

        public static implicit operator PaletaColeccion(int cant)
        {
            PaletaColeccion retorno;

            retorno = new PaletaColeccion(cant);

            return retorno;
        }

        public static bool operator ==(PaletaColeccion obj1, Tempera obj2)
        {
            int indice = 0;
            bool retorno = false;
            
            foreach (Tempera item in obj1._colores)
            {
                if (Object.Equals(obj1, null))
                {
                    if (obj1._colores[indice] == obj2)
                    {
                        retorno = true;
                        break;
                    }
                }

                indice++;
            }

            return retorno;
        }

        public static bool operator !=(PaletaColeccion obj1, Tempera obj2)
        {
            return !(obj1 == obj2);
        }

        public static Paleta operator +(PaletaColeccion obj1, Tempera obj2)
        {
            int indice=0;
            int indice2=0;

            indice = obj1._colores.Count;
            //indice2 = obj1.ObtenerIndice(obj2);

            if(obj1 == obj2)
            {
                if (indice==-1 && indice2 >=0)
                {
                    obj1._colores[indice2] += obj2;
                }
            }
            else
            {
                if (indice > -1)
                {
                    obj1._colores[indice] = obj2;
                }
            }

            return obj1;
        }

        public static Paleta operator -(PaletaColeccion obj1, Tempera obj2)
        {
            int indice=0;
            sbyte paletaInt;
            sbyte temperaInt;

            indice = obj1._colores.Count;

            if (obj1 == obj2)
            {
                if (indice >= 0)
                {
                    paletaInt = (sbyte)obj1._colores[indice];
                    temperaInt = (sbyte)obj2;

                    if (paletaInt - temperaInt <= 0)
                    {
                        obj1._colores[indice] = null;
                        //obj1._cantMaxElementos--;
                    }

                    else
                    {
                        obj1._colores[indice] += (sbyte) (temperaInt * (-1));//Aca tengo que usar += y multiplicar por -1 el otro parametro ya que en la clase tempera tengo sobrecarga de + entre tempera y sbyte pero no de -
                    }
                }
            }      

            return obj1;
        }
    }
}