﻿using System;

namespace EntidadesClase07
{
    public class Class1
    {
       
    }
}
