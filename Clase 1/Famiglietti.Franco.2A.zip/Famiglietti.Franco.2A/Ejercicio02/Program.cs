﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int cuadrado;
            int cubo;
            int contador=0;

            do
            {
                if (contador == 0)
                    Console.Write("Ingrese un numero: ");
                if (contador != 0)
                    Console.Write("ERROR. ¡Reingresar número!: ");
                numero = int.Parse(Console.ReadLine());
                contador++;
            } while (numero < 0);

            cuadrado = (int) Math.Pow(numero, 2);
            cubo = (int) Math.Pow(numero, 3);

            Console.WriteLine("El cuadrado de {0} es {1} y el cubo es {2}", numero, cuadrado, cubo);
            Console.ReadLine();
        }
    }
}
