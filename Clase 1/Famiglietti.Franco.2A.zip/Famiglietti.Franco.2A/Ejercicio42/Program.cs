using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio42
{
  class Program
  {
    static void Main(string[] args)
    {
      MetodoEstatico(1, 0);
    }

    static void MetodoEstatico(float a, float b)
    {
      try
      {
        float division = a / b;
      }

      catch (DivideByZeroException e)
      {
        Console.Write(e.Message);
        MetodoEstatico(e);
      }
    }

    public Main()
    {
      try
      {

      }
    }

  }
}
