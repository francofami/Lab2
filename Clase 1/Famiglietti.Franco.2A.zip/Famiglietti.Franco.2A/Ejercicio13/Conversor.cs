﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Conversor
    {
        public static string DecimalBinario(double num)
        {
            string retorno="";
            double resultado;


            if (num % 2 > 0)
            {
                retorno += "1";
            }
            else
            {
                retorno += "0";
            }

            resultado = num / 2;
           
            while(resultado>1)
            {
                if(resultado % 2 > 0)
                {
                    retorno += "1";
                }
                else
                {
                    retorno += "0";
                }

                resultado = resultado / 2;
            }

            if(resultado==1)
            {
                retorno += "1";
            }

            char[] charArray = retorno.ToCharArray();
            Array.Reverse(charArray);
            retorno = new string(charArray);

            return retorno;
        }

        /*public static double BinarioDecimal(string bin)
        {
            double retorno;



            return retorno;
        }*/
    }
}
