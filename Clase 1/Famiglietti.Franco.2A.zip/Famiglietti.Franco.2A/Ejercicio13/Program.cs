﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcion;
            double num;
            string bin;

            Console.WriteLine("1. Convertir de decimal a binario\n2. Convertir de binario a decimal");
            opcion=int.Parse(Console.ReadLine());

            switch(opcion)
            {
                case 1:
                    {
                        Console.WriteLine("Ingrese numero decimal");
                        num = double.Parse(Console.ReadLine());

                        Console.WriteLine("Num binario: {0}",Conversor.DecimalBinario(num));
                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("Ingrese numero decimal");
                        bin = Console.ReadLine();

                    }
                    break;
                default:
                    break;
            }

            Console.ReadLine();
        }
    }
}
