﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio04
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=1;
            int j;
            int contadorPerfectos = 0;
            int acumuladorDivisores = 0;
            bool esPerfecto;

            do
            {
                do
                {
                    acumuladorDivisores = 0;
                    esPerfecto = false;

                    i++;

                    for (j=1;j<i;j++)
                    {
                        if(i % j == 0)
                        {
                            acumuladorDivisores += j;
                        }                    
                    }

                    if (acumuladorDivisores == i)
                    {
                        esPerfecto = true;
                    }

                } while (esPerfecto!=true);

                contadorPerfectos++;

                Console.WriteLine("Numero perfecto: {0}", i);

            }while (contadorPerfectos != 4);

            Console.ReadLine();
        }
    }
}
