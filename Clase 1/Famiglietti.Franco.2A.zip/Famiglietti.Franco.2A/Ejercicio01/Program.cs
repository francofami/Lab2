﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
            float numero;
            float maximo=0;
            float minimo=0;
            float promedio;
            float acumulador = 0;
            int i;

            for (i = 0; i < 5; i++)
            {
                Console.Write("\nIngrese un numero: ");
                numero = float.Parse(Console.ReadLine());

                if (i == 0)
                {
                    maximo = minimo = numero;
                }

                if (numero < minimo)
                    minimo = numero;
                if (numero > maximo)
                    maximo = numero;

                acumulador += numero;
            }

            promedio = acumulador / i;

            Console.WriteLine("El valor maximo es: {0:0.00}\nEl valor minimo es: {1:0.00}\nEl promedio es: {2:0.00}", maximo, minimo, promedio);

            Console.ReadLine();
        }
    }
}
