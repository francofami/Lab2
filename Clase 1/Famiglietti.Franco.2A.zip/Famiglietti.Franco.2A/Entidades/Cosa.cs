﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades //Lo tuve que renombrar al nombre del namespace actual
{
    class Cosa
    {
        public string cadena;
        public double numero;
        public DateTime fecha;

        public static string Mostrar(Cosa parametro)
        {
            string retorno="";

            retorno = parametro.Mostrar();

            return retorno;
        }

        private string Mostrar()
        {
            #region

            string retorno = "";

            retorno = this.cadena;

            retorno += " - ";

            retorno += this.numero.ToString();

            retorno += " - ";

            retorno += this.fecha.ToShortDateString();

            return retorno;

            #endregion
        }

        public Cosa()
        {
            this.cadena = "Sin valor";
            this.numero = 1.9;
            this.fecha = DateTime.Now;
        }

        public Cosa(string c) : this() //Aca lo que hago con el :this() es llamar a Cosa(), asi me ahorro codigo
        {
            this.cadena = c;
            //this.numero = 1.9;
            //this.fecha = DateTime.Now;
        }

        public Cosa(string c, double b) :this(c)
        {
            this.cadena = c;
            this.numero = b;
            //this.fecha = DateTime.Now
        }

        public Cosa(string c, double b, DateTime a) :this(c,b)
        {
            this.cadena = c;
            this.numero = b;
            this.fecha = a;
        }

        public void EstablecerValor(string c)
        {
            this.cadena = c;
        }

        public void EstablecerValor(DateTime a)
        {
            this.fecha = a;
        }

        public void EstablecerValor(double b)
        {
            this.numero = b;
        }

}
}
