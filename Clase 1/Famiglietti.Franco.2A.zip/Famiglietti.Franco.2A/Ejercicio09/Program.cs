﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio09
{
    class Program
    {
        static void Main(string[] args)
        {
            int altura;
            int i;
            int j;
            string piramide = "*\n";

            Console.WriteLine("Inserte altura: ");
            altura = int.Parse(Console.ReadLine());

            for (i = 1; i < altura; i++)
            {

                for (j = 0; j < i; j++)
                {
                    piramide += "*";
                }

                for (j = 0; j < i; j++)
                {
                    piramide += "*";
                }

                piramide += "\n";
            }

            Console.WriteLine("{0}", piramide);

            Console.ReadLine();
        }
    }
}
