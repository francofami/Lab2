﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio09
{
    class Program
    {
        static void Main(string[] args)
        {
            int altura;
            int i;
            int j=0;

            Console.WriteLine("Inserte altura: ");
            altura = int.Parse(Console.ReadLine());

            for(i=0;i<altura;i++)
            {
                if(i==0)
                Console.WriteLine("*\n");

                do
                {
                    j++;
                    Console.WriteLine("**");
                    Console.WriteLine("\n");
                } while (j==altura);
                
            }

            Console.ReadLine();
        }
    }
}
