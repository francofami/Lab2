﻿public enum EMarcas
{
    Fiat, Ford, Honda, Iveco, Scania, Zanella
}