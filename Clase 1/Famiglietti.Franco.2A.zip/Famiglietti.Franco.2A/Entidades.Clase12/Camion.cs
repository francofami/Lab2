﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase12
{
    class Camion : Vehiculo
    {
        protected float _tara;

        public Camion(string patente, EMarcas marca, float tara, Byte cantRuedas) : base(patente, cantRuedas, marca)
        {
            this._tara = tara;
        }

        public Camion(Vehiculo vehiculo, float tara) : this(vehiculo.Patente, vehiculo.Marca, tara, vehiculo.CantRuedas)
        {
            
        }

        protected override string Mostrar()
        {
            string retorno = "";

            retorno = base.Mostrar() + this._tara.ToString();

            return retorno;
        }
    }
}
