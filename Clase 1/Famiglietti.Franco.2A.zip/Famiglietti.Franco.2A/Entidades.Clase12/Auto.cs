﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase12
{
    public class Auto : Vehiculo
    {
        protected int _cantidadAsientos;

        public Auto(string patente, EMarcas marca, int cantidadAsientos, Byte cantRuedas) : base(patente, cantRuedas, marca)
        {
            this._cantidadAsientos = cantidadAsientos;
        }

        public Auto(string patente, EMarcas marca, int cantidadAsientos) : this(patente, marca, cantidadAsientos, 4)
        {

        }

        protected override string Mostrar()
        {
            string retorno = "";

            retorno = base.Mostrar() + this._cantidadAsientos.ToString();

            return retorno;
        }
    }
}
