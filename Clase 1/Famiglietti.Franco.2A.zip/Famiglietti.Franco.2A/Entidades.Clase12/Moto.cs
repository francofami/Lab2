﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase12
{
    public class Moto : Vehiculo
    {
        protected float _cilindrada;

        public Moto(string patente, EMarcas marca, float cilindrada, Byte cantRuedas) : base(patente, cantRuedas, marca)
        {
            this._cilindrada = cilindrada;
        }

        public Moto(EMarcas marca, float cilindrada, string patente, Byte cantRuedas) : this(patente, marca, cilindrada, cantRuedas)
        {

        }

        protected override string Mostrar()
        {
            string retorno = "";

            retorno = base.Mostrar() + this._cilindrada.ToString();

            return retorno;
        }
    }
}
