﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase12
{
    public class Vehiculo
    {
        protected string _patente;

        public string Patente
        {
            get
            {
                return this._patente;
            }
        }

        protected Byte _cantRuedas;

        public Byte CantRuedas
        {
            get
            {
                return this._cantRuedas;
            }

            set
            {
                this._cantRuedas = value;
            }
        }

        protected EMarcas  _marca;

        public EMarcas Marca
        {
            get
            {
                return this._marca;
            }
        }

        protected virtual string Mostrar()
        {
            string retorno = "";

            retorno = "Patente: " + this._patente;

            retorno += "\nCantidad de ruedas: " + this._cantRuedas.ToString();

            retorno += "\nMarca: " + this._marca.ToString();

            return retorno;
        }

        public Vehiculo(string patente,  Byte cantRuedas, EMarcas marca)
        {
            this._patente = patente;
            this._cantRuedas = cantRuedas;
            this._marca = marca;
        }

        public override string ToString()
        {

            string retorno = "";
            retorno = this.Mostrar();

            return retorno;
        }


        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool retorno = false;

            if(v1._patente == v2._patente && v1._marca == v2._marca)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }
    }
}
