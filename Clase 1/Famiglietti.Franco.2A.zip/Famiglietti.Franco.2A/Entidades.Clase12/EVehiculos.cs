﻿public enum EVehiculos
{
    Auto, Camión, Moto
}