﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase12
{
    class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(string razonSocial) : this()
        {
            this._razonSocial = razonSocial;
        }

        static Lavadero()
        {
            Random rnd = new Random();

            _precioAuto = rnd.Next(150, 565);
            _precioCamion = rnd.Next(150, 565);
            _precioMoto = rnd.Next(150, 565);
        }

        public string LavaderoToString
        {
            get
            {
                string retorno = ""; 

                retorno = "\nPrecio auto: " + _precioAuto.ToString();
                retorno += "\nPrecio moto: " + _precioMoto.ToString();
                retorno += "\nPrecio vehiculo: " + _precioCamion.ToString();
                retorno += "\nRazon social: " + this._razonSocial;

                foreach(Vehiculo vehiculo in _vehiculos)
                retorno += vehiculo.ToString();

                return retorno;
            }
        }

        public List<Vehiculo> Vehiculos
        {
            get
            {
                return this._vehiculos;
            }
        }
        
        public Double MostrarTotalFacturado()
        {
            Double retorno=0;

            retorno += MostrarTotalFacturado(EVehiculos.Auto);
            retorno += MostrarTotalFacturado(EVehiculos.Camión);
            retorno += MostrarTotalFacturado(EVehiculos.Moto);

            return retorno;
        }

        public Double MostrarTotalFacturado(EVehiculos enumVehiculo)
        {
            Double retorno = 0;

            foreach(Vehiculo item in this._vehiculos)
            {
                switch(enumVehiculo)
                {
                    case EVehiculos.Auto:
                        if(item is Auto)
                        {
                            retorno += _precioAuto;
                        }
                        break;
                    case EVehiculos.Moto:
                        if (item is Moto)
                        {
                            retorno += _precioMoto;
                        }
                        break;
                    case EVehiculos.Camión:
                        if (item is Camion)
                        {
                            retorno += _precioCamion;
                        }
                        break;
                }
            }

            return retorno;
        }

        public static bool operator ==(Lavadero lav, Vehiculo veh)
        {
            bool retorno = false;



            return retorno;
        }

    }
}
