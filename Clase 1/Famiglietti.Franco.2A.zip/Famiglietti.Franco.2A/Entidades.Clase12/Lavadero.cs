﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase12
{
    public class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(string razonSocial) : this()
        {
            this._razonSocial = razonSocial;
        }

        static Lavadero()
        {
            Random rnd = new Random();

            _precioAuto = rnd.Next(150, 565);
            _precioCamion = rnd.Next(150, 565);
            _precioMoto = rnd.Next(150, 565);
        }

        public string LavaderoToString
        {
            get
            {
                string retorno = ""; 

                foreach(Vehiculo vehiculo in _vehiculos)
                retorno += vehiculo.ToString();

                return retorno;
            }
        }

        public List<Vehiculo> Vehiculos
        {
            get
            {
                return this._vehiculos;
            }
        }
        
        public Double MostrarTotalFacturado()
        {
            Double retorno=0;

            retorno += MostrarTotalFacturado(EVehiculos.Auto);
            retorno += MostrarTotalFacturado(EVehiculos.Camión);
            retorno += MostrarTotalFacturado(EVehiculos.Moto);

            return retorno;
        }

        public Double MostrarTotalFacturado(EVehiculos enumVehiculo)
        {
            Double retorno = 0;

            foreach(Vehiculo item in this._vehiculos)
            {
                switch(enumVehiculo)
                {
                    case EVehiculos.Auto:
                        if(item is Auto)
                        {
                            retorno += _precioAuto;
                        }
                        break;
                    case EVehiculos.Moto:
                        if (item is Moto)
                        {
                            retorno += _precioMoto;
                        }
                        break;
                    case EVehiculos.Camión:
                        if (item is Camion)
                        {
                            retorno += _precioCamion;
                        }
                        break;
                }
            }

            return retorno;
        }

        public static bool operator ==(Lavadero lav, Vehiculo veh)
        {
            bool retorno = false;

            foreach (Vehiculo vehiculo in lav._vehiculos)
            {
                if (vehiculo == veh)
                {
                    retorno = true;
                }
            }  
            return retorno;
        }

        public static bool operator !=(Lavadero lav, Vehiculo veh)
        {
            return !(lav == veh);
        }

        public static int operator ==(Vehiculo veh, Lavadero lav)
        {
            int retorno = -1;
            int i;

            for (i = 0; i < lav._vehiculos.Count; i++)
            {
                if (veh == lav._vehiculos[i])
                {
                    retorno = i;
                }
            }

            return retorno;
        }

        public static int operator !=(Vehiculo veh, Lavadero lav)
        {
            return -1;
        }

        public static Lavadero operator +(Lavadero lav, Vehiculo veh)
        {
            Lavadero retorno;
            int i;

            retorno = lav;

            if(lav!=veh)
            {
                retorno += veh;
            }

            return retorno;
        }

        public static Lavadero operator -(Lavadero lav, Vehiculo veh)
        {
            Lavadero retorno;
            int i;

            retorno = lav;

            if (lav == veh)
            {
                retorno -= veh;
            }

            return retorno;
        }

        /*public static Lavadero operator +(Lavadero L, Vehiculo V)
    {
      if (L != V)
        L._vehiculos.Add(V);
      
      return L;
    }

    public static Lavadero operator -(Lavadero L, Vehiculo V)
    {
      int index = (V == L);
      L._vehiculos.RemoveAt(index);

      return L;
    }*/

        public static int OrdenarVehiculosPorPatente(Vehiculo veh1, Vehiculo veh2)
        {
            int retorno = -1;

            retorno = String.Compare(veh1.Patente, veh2.Patente);

            if(retorno == 1)
            {
                retorno = -1;
            }

            if(retorno ==-1)
            {
                retorno = 1;
            }

            return retorno;
        }

        public int OrdenarVehiculosPorMarca(Vehiculo veh1, Vehiculo veh2)
        {
            int retorno=-1;

            retorno = String.Compare(veh1.Marca.ToString(), veh2.Marca.ToString());

            if (retorno == 1)
            {
                retorno = -1;
            }

            if (retorno == -1)
            {
                retorno = 1;
            }

            return retorno;
        }

    }
}
