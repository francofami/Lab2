﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio06
{
    class Program
    {
        static void Main(string[] args)
        {
            int año;
            bool esBisiesto = false;

            Console.WriteLine("Ingrese año: ");
            año = int.Parse(Console.ReadLine());

            if(año % 4 == 0)
            {
                esBisiesto = true;

                if(año % 100 == 0)
                {
                    esBisiesto = false;

                    if(año % 400 == 0)
                    {
                        esBisiesto = true;
                    }
                }
            }

            if(esBisiesto==true)
            {
                Console.WriteLine("El año {0} es bisiesto.", año);
            }
            else
            {
                Console.WriteLine("El año {0} no es bisiesto.", año);
            }

            Console.ReadLine();
        }
    }
}
