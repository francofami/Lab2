﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio12
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int acumulador = 0;
            char respuesta;

            do
            {
                Console.WriteLine("Ingrese numero: ");
                numero = int.Parse(Console.ReadLine());
                acumulador += numero;

                Console.WriteLine("¿Desea seguir ingresando numeros? S/N: ");
                respuesta = char.Parse(Console.ReadLine());

            } while (ValidarRespuesta.ValidaS_N(respuesta)==true);

            Console.WriteLine("La suma de los numeros ingresados es: {0} ",acumulador);
            Console.ReadLine();
        }
    }
}
