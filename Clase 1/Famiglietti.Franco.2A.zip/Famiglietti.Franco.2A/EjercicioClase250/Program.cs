﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase25;
using Entidades.Externa;
using Entidades.Externa.Sellada;

namespace EjercicioClase25
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona persona1 = new Persona("Juan", "Perez", 33, EntidadesClase25.ESexo.Masculino);

            Console.WriteLine("Nombre: " + persona1.Nombre);
            Console.WriteLine("Apellido: " + persona1.Apellido);
            Console.WriteLine("Edad: " + persona1.Edad);
            Console.WriteLine("Sexo: " + persona1.Sexo + "\n");

            Console.WriteLine(persona1.obtenerDatos());

            //Para visualizar un dll boton derecho en la entidad -> ver en el explorador de objetos

            PersonaExterna persona2 = new PersonaExterna("Jorge", "Gomez", 55, Entidades.Externa.ESexo.Masculino);

            PersonaExternaHeredada persona3 = new PersonaExternaHeredada("Jose", "Gonzales", 25, Entidades.Externa.ESexo.Masculino);
            // En este caso el dll que usé tiene sus atributos protegidos, por lo tanto tuve que crear una nueva clase y heredar del dll para acceder

            Console.WriteLine(persona3.obtenerDatos());

            PersonaExternaSellada persona4 = new PersonaExternaSellada("Jacinto", "Ramirez", 97, Entidades.Externa.Sellada.ESexo.Masculino);
            // En este caso el dll es una clase sellada (sealed), pero sus propiedades publicas

            Console.WriteLine(persona4.ObtenerDatos());
            Console.WriteLine("Evaluo si persona4 es nula: ");
            Console.WriteLine("Es nulo: " + persona4.EsNulo());
            Console.ReadKey();

            //Hago nula persona4
            Console.WriteLine("hago nula la persona4: ");
            persona4 = null;
            Console.WriteLine("Es nulo: " + persona4.EsNulo());
            Console.ReadKey();

            Console.Write("El numero 5456 tiene esta cant de digitos: ");
            Console.WriteLine(Extensora.CantidadDigitos(5456));

            int a = 348;
            Console.Write(a.ToString() + " tiene la misma cantidad de digitos que 5: ");
            Console.WriteLine(a.TieneLaMismaCantidad(5));

            persona1.AgregarDB();

            Persona persona5 = new Persona("Agustin", "Famiglietti", 44, EntidadesClase25.ESexo.Masculino);

            persona5.ModificarDB(7);

            persona1.BorrarDB(7);

            List<Persona> lista = persona1.TraerDB(); //Es una instancia de persona1 porque en TraerDB puse (Persona persona)

            foreach (Persona p in lista)
            {
                Console.WriteLine(p.obtenerDatos());
            }

            

            Console.ReadKey();
        }
    }
}
