﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesClase16Parte2;
using EntidadesClase16;

namespace EjercicioClase16Parte2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Cocina c1 = new Cocina(111, 12300, false);
            Cocina c2 = new Cocina(112, 15000, true);
            Cocina c3 = new Cocina(113, 5600, false);
            DepositoDeCocinas dc = new DepositoDeCocinas(5);
            dc.Agregar(c1);
            dc.Agregar(c2);
            if (!(dc + c3))
            {
                Console.WriteLine("No se pudo agregar el item!!!");
            }
            Console.WriteLine(dc);
            dc.Remover(c2);
            if (!(dc - c2))
            {
                Console.WriteLine("No se pudo remover el item!!!");
            }
            Console.WriteLine(dc);

            if(c1.Guardar(@"D:\Mis Documentos\Cocinas.txt") == true) //O puedo hacer D:\\Mis Documentos\\Cocinas.txt
            {
                Console.WriteLine("\nSe pudo guardar el archivo");
            }
            else
            {
                Console.WriteLine("\nNo se pudo guardar el archivo");
            }

            if (c1.Recuperar(@"D:\Mis Documentos\Cocinas.txt") == true) //O puedo hacer D:\\Mis Documentos\\Cocinas.txt
            {
                Console.WriteLine("\nSe pudo leer el archivo");
            }
            else
            {
                Console.WriteLine("\nNo se pudo leer el archivo");
            }

            Console.ReadLine();*/

            Cocina c1 = new Cocina(111, 12300, false);
            Cocina c2 = new Cocina(112, 15000, true);
            Cocina c3 = new Cocina(113, 5600, false);
            Deposito<Cocina> dc = new Deposito<Cocina>(5);
            dc.Agregar(c1);
            dc.Agregar(c2);
            if (!(dc + c3))
            {
                Console.WriteLine("No se pudo agregar el item!!!");
            }
           
            Console.WriteLine(dc);
           
            dc.Remover(c2);
            if (!(dc - c2))
            {
                Console.WriteLine("No se pudo remover el item!!!");
            }
            
            Console.WriteLine(dc);
            Console.ReadLine();
        }
    }
}
