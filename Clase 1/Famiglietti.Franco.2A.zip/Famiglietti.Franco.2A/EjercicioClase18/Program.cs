﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClaseArchivos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Escribo y leo en Mis Documentos

            if (AdministradorArchivos.Escribir(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\ArchivoMisDocumentos.txt", "Este mensaje se deberia mostrar y esta guardado en Mis Documentos") == true)
            {
                Console.WriteLine("\nSe pudo guardar el archivo");
            }
            else
            {
                Console.WriteLine("\nNo se pudo guardar el archivo");
            }

            string mostrar = "";

            if (AdministradorArchivos.Leer(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\ArchivoMisDocumentos.txt",out mostrar) == true) 
            {               
                Console.WriteLine("\nSe pudo leer el archivo");
                Console.WriteLine(mostrar);
            }
            else
            {
                Console.WriteLine("\nNo se pudo leer el archivo");
            }

            //Escribo y leo en el Escritorio

            if (AdministradorArchivos.Escribir(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\ArchivoEscritorio.txt", "Este mensaje se deberia mostrar y esta guardado en el escritorio") == true)
            {
                Console.WriteLine("\nSe pudo guardar el archivo");
            }
            else
            {
                Console.WriteLine("\nNo se pudo guardar el archivo");
            }


            if (AdministradorArchivos.Leer(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\ArchivoEscritorio.txt", out mostrar) == true)
            {
                Console.WriteLine("\nSe pudo leer el archivo");
                Console.WriteLine(mostrar);
            }
            else
            {
                Console.WriteLine("\nNo se pudo leer el archivo");
            }

            //Escribo y leo en Mis Imagenes

            if (AdministradorArchivos.Escribir(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\ArchivoMisImagenes.txt", "Este mensaje se deberia mostrar y esta guardado en mis imagenes") == true)
            {
                Console.WriteLine("\nSe pudo guardar el archivo");
            }
            else
            {
                Console.WriteLine("\nNo se pudo guardar el archivo");
            }

            if (AdministradorArchivos.Leer(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures) + "\\ArchivoMisImagenes.txt", out mostrar) == true)
            {
                Console.WriteLine("\nSe pudo leer el archivo");
                Console.WriteLine(mostrar);
            }
            else
            {
                Console.WriteLine("\nNo se pudo leer el archivo");
            }

            //Escribo y leo en el directorio donde esta el ejecutable

            if (AdministradorArchivos.Escribir(AppDomain.CurrentDomain.BaseDirectory + "\\Archivo.txt", "Este mensaje se deberia mostrar y esta guardado en la carpeta del ejecutable") == true)
            {
                Console.WriteLine("\nSe pudo guardar el archivo");
            }
            else
            {
                Console.WriteLine("\nNo se pudo guardar el archivo");
            }

            if (AdministradorArchivos.Leer(AppDomain.CurrentDomain.BaseDirectory + "\\Archivo.txt", out mostrar) == true)
            {
                Console.WriteLine("\nSe pudo leer el archivo");
                Console.WriteLine(mostrar);
            }
            else
            {
                Console.WriteLine("\nNo se pudo leer el archivo");
            }

            Console.ReadLine();
        }
    }
}
