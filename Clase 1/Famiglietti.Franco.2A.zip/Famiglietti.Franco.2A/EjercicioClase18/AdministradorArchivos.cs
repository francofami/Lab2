﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EjercicioClaseArchivos
{
    public static class AdministradorArchivos
    {
        public static bool Escribir(string path, string texto)
        {
            bool retorno = false;

            StreamWriter sw;

            sw = new StreamWriter(path, false);

            try
            {
                sw.WriteLine(texto);
                sw.Close();
                retorno = true;

                return retorno;
            }

            catch (Exception e)
            {
                retorno = false;

                return retorno;
            }
        }

        public static bool Leer(string path, out string texto)
        {
            bool retorno = false;

            StreamReader sw;

            sw = new StreamReader(path, false);

            try
            {
                texto = sw.ReadToEnd();
                sw.Close();
                retorno = true;
                return retorno;
            }

            catch (Exception e)
            {
                retorno = false;
                texto = "Error";
                return retorno;
            }
        }
    }
}
