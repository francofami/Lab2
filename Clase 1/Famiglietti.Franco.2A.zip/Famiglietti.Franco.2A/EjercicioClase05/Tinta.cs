﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
    class Tinta
    {
        private ConsoleColor _color;
        private ETipoTinta _tipo;

        public Tinta()
        {
            this._color = ConsoleColor.Blue;
            this._tipo = ETipoTinta.ConBrillito;
        }

        public Tinta(ConsoleColor color) : this()
        {
            this._color = color;
        }

        public Tinta(ETipoTinta tipo) : this()
        {
            this._tipo = tipo;
        }

        public Tinta(ETipoTinta tipo, ConsoleColor color) : this(color)
        {
            this._tipo = tipo;
        }

        public static string Mostrar(Tinta objeto)
        {
            string retorno="";

            retorno = objeto.Mostrar();

            return retorno;
        }

        private string Mostrar()
        {
            string retorno="";

            retorno = this._color.ToString();

            retorno += " - ";

            retorno += this._tipo.ToString();

            return retorno;
        }

        public static bool operator ==(Tinta obj1, Tinta obj2)
        {
            bool retorno = false;

            if (obj1._color == obj2._color && obj1._tipo == obj2._tipo)
                retorno = true;

            return retorno;
        }

        public static bool operator !=(Tinta obj1, Tinta obj2)
        {
            return !(obj1 == obj2);
        }
    }
}
