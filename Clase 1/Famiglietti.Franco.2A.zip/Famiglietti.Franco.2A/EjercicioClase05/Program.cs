using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
  class Program
  {
    static void Main(string[] args)
    {
      Tinta obj1 = new Tinta();
      Tinta obj2 = new Tinta(ConsoleColor.Cyan);
      Tinta obj3 = new Tinta(ETipoTinta.China);
      Tinta obj4 = new Tinta(ETipoTinta.Comun, ConsoleColor.DarkBlue);

      if (obj1 == obj4)
      {
        Console.WriteLine("Este mensaje nunca debe aparecer");
      }

      if (!(obj2 == obj4))
      {
        Console.WriteLine("Este mensaje siempre debe aparecer");
      }

      Console.WriteLine(Tinta.Mostrar(obj1));
      Console.WriteLine(Tinta.Mostrar(obj2));
      Console.WriteLine(Tinta.Mostrar(obj3));
      Console.WriteLine(Tinta.Mostrar(obj4));


      Pluma obj5 = new Pluma("Bic", 50, obj3);

      Console.WriteLine(obj5); //Como hice un implicit en Pluma.cs puedo mostrarlo asi

      if (obj5 == obj4)
      {
        Console.WriteLine("Este mensaje nunca debe aparecer");
      }

      if (!(obj2 == obj4))
      {
        Console.WriteLine("Este mensaje siempre debe aparecer");
      }

      obj5 = obj5 + obj3;
      Console.WriteLine(obj5);

      obj5 = obj5 - obj3;
      Console.WriteLine(obj5);

      obj5 = obj5 + obj2; //No deberìa sumar porque no son iguales
      Console.WriteLine(obj5);

      Pluma obj6 = new Pluma("Lapicera", 98, obj4);
      obj6 = obj6 + obj4;
      Console.WriteLine(obj6);

      Pluma obj7 = new Pluma("Pelikan", 2, obj2);
      obj7 -= obj2;
      Console.WriteLine(obj7);

      Console.ReadLine();
    }
  }
}
