﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta obj1 = new Tinta();
            Tinta obj2 = new Tinta(ConsoleColor.Cyan);
            Tinta obj3 = new Tinta(ETipoTinta.China);
            Tinta obj4 = new Tinta(ETipoTinta.Comun, ConsoleColor.DarkBlue);

            if(obj1==obj4)
            {
                Console.WriteLine("Este mensaje nunca debería aparecer");
            }

            if (!(obj2 == obj4))
            {
                Console.WriteLine("Este mensaje siempre debería aparecer");
            }

            Console.WriteLine(Tinta.Mostrar(obj1));
            Console.WriteLine(Tinta.Mostrar(obj2));
            Console.WriteLine(Tinta.Mostrar(obj3));
            Console.WriteLine(Tinta.Mostrar(obj4));

            Console.ReadLine();
        }
    }
}
