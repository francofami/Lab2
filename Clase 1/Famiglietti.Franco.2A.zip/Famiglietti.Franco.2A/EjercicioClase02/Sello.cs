﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase02
{
    class Sello
    {
        public static string mensaje;
        public static ConsoleColor color;

        public static string Imprimir()
        {
            string mensajeFormateado = "";

            if (Sello.TryParse(Sello.mensaje, out mensajeFormateado))
            {
                Sello.mensaje = mensajeFormateado;
                mensajeFormateado = ArmarFormatoMensaje();
            }
            else
            {
                Console.WriteLine("No se puede recuadrar el mensaje");
            }

            return mensajeFormateado;
        }

        public static void Borrar()
        {
            Sello.mensaje = "";
        }
    
        public static void ImprimirEnColor()
        {
            Console.ForegroundColor = Sello.color;
            Console.WriteLine(Sello.Imprimir());
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        private static string ArmarFormatoMensaje() //Es private, por lo tanto solo puedo acceder dentro de la clase
        {
            int largoMensaje;
            int i;
            string mensajeConFormato = "";

            largoMensaje = Sello.mensaje.Length + 2; 

            for(i=0;i<largoMensaje;i++)
            {
                mensajeConFormato += "*"; //Aca está concatenando, agrega el caracter * al final del ultimo caracter de mi string
            }

            mensajeConFormato += "\n";
            mensajeConFormato += "*";
            mensajeConFormato += Sello.mensaje;
            mensajeConFormato += "*";
            mensajeConFormato += "\n";

            for (i = 0; i < largoMensaje; i++)
            {
                mensajeConFormato += "*"; //Aca está concatenando, agrega el caracter * al final del ultimo caracter de mi string
            }

            return mensajeConFormato;
        }

        private static bool TryParse(string mensaje, out string salida) //El out transforma el comportamiento del parámetro para que sea de salida.
        {
            bool esMayorACero = false;
            int largoMensaje;

            largoMensaje = Sello.mensaje.Length;

            if(largoMensaje>0)
            {
                esMayorACero = true;
            }

            salida = mensaje;

            return esMayorACero;
        }

    }
}
