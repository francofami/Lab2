﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese mensaje: ");
            Sello.mensaje = Console.ReadLine();
            
            //Sello.mensaje = "Franco";
            Console.WriteLine(Sello.Imprimir());

            Sello.color = ConsoleColor.Red;
            Sello.ImprimirEnColor();

            Console.WriteLine(Sello.Imprimir()); 

            Console.ReadLine();
        }
    }
}
