﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    public interface IARBA
    {
        double CalcularImpuesto();

        double PropiedadL
        {
            get;
        }

        double PropiedadLE
        {
            get;
            set;
        }

        double PropiedadE
        {
            set;
        }
    }
}
