﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    class Comercial : Avion, IARBA
    {
        protected int _capacidadPasajeros;

        public Comercial(double precio, double velocidad, int pasajeros) : base(precio, velocidad)
        {
            this._capacidadPasajeros = pasajeros;
        }

        public new double CalcularImpuesto()
        {
            double retorno = 0;

            retorno = (base._precio * 0.25) + base._precio;

            return retorno;
        }

        public new double PropiedadL
        {
            get
            {
                double retorno = 0;

                retorno = CalcularImpuesto();

                return retorno;
            }
        }

        public new double PropiedadLE
        {
            get
            {
                double impuesto = 0;

                impuesto = CalcularImpuesto();

                return impuesto;
            }

            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        public new double PropiedadE
        {
            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }
    }
}
