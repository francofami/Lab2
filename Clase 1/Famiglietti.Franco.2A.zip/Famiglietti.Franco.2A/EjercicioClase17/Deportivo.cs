﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    public class Deportivo : Auto, IAFIP, IARBA
    {
        protected int _caballosFuerza;

        public Deportivo(double precio, string patente, int hp) : base(precio, patente)
        {
            this._caballosFuerza = hp;
        }

        public double CalcularImpuesto()
        {
            double retorno=0;

            retorno = (base._precio * 0.28) + base._precio;

            return retorno;
        }

        double IARBA.CalcularImpuesto()
        {
            double retorno = 0;

            retorno = (base._precio * 0.23) + base._precio;

            return retorno;
        }

        double IARBA.PropiedadL
        {
            get
            {
                double impuesto = 0;

                impuesto = ((IARBA)this).CalcularImpuesto();

                return impuesto;
            }
        }

        public double PropiedadL
        {
            get
            {
                double impuesto = 0;

                impuesto = CalcularImpuesto();

                return impuesto;
            }
        }

        public double PropiedadLE
        {
            get
            {
                double impuesto = 0;

                impuesto = CalcularImpuesto();

                return impuesto;
            }

            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        double IARBA.PropiedadLE
        {
            get
            {
                double impuesto = 0;

                impuesto = ((IARBA)this).CalcularImpuesto();

                return impuesto;
            }

            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        public double PropiedadE
        {
            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        double IARBA.PropiedadE
        {
            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }
    }
}
