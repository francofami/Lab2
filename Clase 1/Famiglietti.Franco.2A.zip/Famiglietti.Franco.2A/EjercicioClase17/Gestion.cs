﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    static class Gestion
    {
        public static double MostrarImpuestoNacional(IAFIP bienPunible)
        {
            double retorno=0;

            retorno = bienPunible.CalcularImpuesto();

            return retorno;
        }

        public static double MostrarImpuestoProvincial(IARBA bienPunible)
        {
            double retorno = 0;

            retorno = bienPunible.CalcularImpuesto();

            return retorno;
        }
    }
}
