﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    class Carreta : Vehiculo, IARBA
    {
        public Carreta(double precio) : base(precio)
        {

        }

        public double CalcularImpuesto()
        {
            double retorno = 0;

            retorno = (base._precio * 0.18) + base._precio;

            return retorno;
        }

        public double PropiedadL
        {
            get
            {
                double retorno = 0;

                retorno = CalcularImpuesto();

                return retorno;
            }
        }

        public double PropiedadLE
        {
            get
            {
                double impuesto = 0;

                impuesto = CalcularImpuesto();

                return impuesto;
            }

            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        public double PropiedadE
        {
            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }
    }
}
