﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioClase17
{
    public class Avion : Vehiculo, IAFIP, IARBA
    {
        protected double _velocidadMaxima;

        public Avion(double precio, double velMax) : base(precio)
        {
            this._velocidadMaxima = velMax;
        }

        public double CalcularImpuesto()
        {
            double retorno=0;

            retorno = (base._precio * 0.33) + base._precio; 

            return retorno;
        }

        double IARBA.CalcularImpuesto()
        {
            double retorno = 0;

            retorno = (0.27 * base._precio) + base._precio;

            return retorno;
        }

        double IARBA.PropiedadL
        {
            get
            {
                double impuesto = 0;

                impuesto = ((IARBA)this).CalcularImpuesto();

                return impuesto;
            }
        }

        public double PropiedadL
        {
            get
            {
                double impuesto = 0;

                impuesto = CalcularImpuesto();

                return impuesto;
            }
        }

        public double PropiedadLE
        {
            get
            {
                double impuesto = 0;

                impuesto = CalcularImpuesto();

                return impuesto;
            }

            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        double IARBA.PropiedadLE
        {
            get
            {
                double impuesto = 0;

                impuesto = ((IARBA)this).CalcularImpuesto();

                return impuesto;
            }

            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }

        public double PropiedadE
        {
            set
            {
                double impuesto=0;

                impuesto = value;
            }
        }

        double IARBA.PropiedadE
        {
            set
            {
                double impuesto = 0;

                impuesto = value;
            }
        }
    }
}
