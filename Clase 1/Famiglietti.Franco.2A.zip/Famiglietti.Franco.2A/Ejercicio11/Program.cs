﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int numero;
            int minimo=0;
            int maximo=0;
            int acumulador=0;
            float promedio;

            for (i=0;i<10;i++)
            {
                Console.WriteLine("Ingrese numero: ");
                numero = int.Parse(Console.ReadLine());

                while(Validación.Validar(numero, -100, 100)==false)
                {
                    Console.WriteLine("Error, reingrese numero (entre -100 y 100:");
                    numero = int.Parse(Console.ReadLine());
                }

                acumulador += numero;

                if (i == 0)
                    minimo = maximo = numero;
                else
                {
                    if(minimo>numero)
                    {
                        minimo = numero;
                    }

                    if(maximo<numero)
                    {
                        maximo = numero;
                    }
                }
            }

            promedio = acumulador / i;

            Console.WriteLine("Promedio: {0}\nMaximo: {1}\nMinimo: {2}",promedio, maximo, minimo);

            Console.ReadLine();
        }
    }
}
