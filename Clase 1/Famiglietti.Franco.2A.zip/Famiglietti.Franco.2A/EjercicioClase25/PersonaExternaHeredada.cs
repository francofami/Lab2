﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;

namespace EntidadesClase25
{
    public class PersonaExternaHeredada : PersonaExterna
    {
        public PersonaExternaHeredada(string nombre, string apellido, int edad, Entidades.Externa.ESexo sexo) : base(nombre, apellido, edad, sexo)
        {

        }

        public string obtenerDatos()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Nombre: " + base._nombre);
            retorno.AppendLine("Apellido: " + base._apellido);
            retorno.AppendLine("Edad: " + base._edad);
            retorno.AppendLine("Sexo: " + base._sexo + "\n");

            return retorno.ToString();
        }
    }
}
