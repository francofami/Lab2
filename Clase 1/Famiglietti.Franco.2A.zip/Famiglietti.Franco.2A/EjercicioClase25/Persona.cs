﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace EntidadesClase25
{
    public enum ESexo
    {
        Masculino, Femenino, Indeterminado
    }

    public class Persona
    {
        protected string _nombre;
        protected string _apellido;
        protected int _edad;
        protected ESexo _sexo;

        public Persona(string nombre, string apellido, int edad, ESexo sexo)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
            this._sexo = sexo;
        }

        //Para mostrarlos puedo usar:
        //Propiedades
        //Metodos getters
        //Metodo obtenerDatos

        public string Nombre
        {
            get
            {
                return this._nombre;
            }
        }

        public string Apellido
        {
            get
            {
                return this._apellido;
            }
        }

        public int Edad
        {
            get
            {
                return this._edad;
            }
        }

        public ESexo Sexo
        {
            get
            {
                return this._sexo;
            }
        }

        public string obtenerDatos()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("Nombre: " + this._nombre);
            retorno.AppendLine("Apellido: " + this._apellido);
            retorno.AppendLine("Edad: " + this._edad);
            retorno.AppendLine("Sexo: " + this._sexo + "\n");

            return retorno.ToString();
        }


        
    }
}
