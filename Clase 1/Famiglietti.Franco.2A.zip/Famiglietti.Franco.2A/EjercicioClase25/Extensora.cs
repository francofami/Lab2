﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa.Sellada;
using System.Data.SqlClient;
using System.Data;

namespace EntidadesClase25
{
    public static class Extensora
    {
        public static string ObtenerDatos(this PersonaExternaSellada persona)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Nombre: " + persona.Nombre);
            sb.AppendLine("Apellido: " + persona.Apellido);
            sb.AppendLine("Edad: " + persona.Edad);
            sb.AppendLine("Sexo: " + persona.Sexo);

            return sb.ToString();
        }

        public static bool EsNulo(this Object objeto)
        {
            bool retorno = false;

            if(Object.Equals(objeto, null))
            {
                retorno = true;
            }

            return retorno;
        }

        public static Int32 CantidadDigitos(this Int32 numero)
        {
            Int32 respuesta = 0;
            Int32 n = numero;
            Int32 retorno = 0;

            while(n>0)
            {
                respuesta = n % 10;

                retorno++;
                n = n / 10;
            }

            return retorno;
        }

        public static bool TieneLaMismaCantidad(this Int32 a, Int32 b)
        {
            bool retorno = false;

            if(CantidadDigitos(a) == CantidadDigitos(b))
            {
                retorno = true;
            }

            return retorno;
        }

        public static List<Persona> TraerDB(this Persona persona)
        {
            List<Persona> nuevaLista = new List<Persona>();
            int indice = 1;
            SqlConnection conexion = new SqlConnection(@"Data Source=LAB5PC23\SQLEXPRESS;Initial Catalog=Personas_DB;Integrated Security=True");

            SqlCommand comandoSql = new SqlCommand();
            comandoSql.CommandType = CommandType.Text;
            comandoSql.Connection = conexion;
            comandoSql.CommandText = string.Format("SELECT * FROM dbo.personas WHERE 1=1");

            conexion.Open();
            SqlDataReader lector;
            lector = comandoSql.ExecuteReader();

            while (lector.Read())
            {
                nuevaLista.Add(new Persona((string)lector[1], (string)lector[2], (int)lector[3], (ESexo)lector[4])); //Empiezo del 1 porque el 0 es el ID en este caso, el 0 no lo muestro
                Console.WriteLine("{0} persona agregada..", indice);
                indice++;
            }

            conexion.Close();

            return nuevaLista;
        }

        public static bool AgregarDB(this Persona persona)
        {
            bool retorno = false; 

            SqlConnection conexion = new SqlConnection(@"Data Source=LAB5PC23\SQLEXPRESS;Initial Catalog=Personas_DB;Integrated Security=True");

            SqlCommand comandoSql = new SqlCommand();
            comandoSql.CommandType = CommandType.Text;
            comandoSql.Connection = conexion;
            comandoSql.CommandText = string.Format("INSERT INTO dbo.personas ([nombre], [apellido], [edad], [sexo]) values ('{0}','{1}',{2}, {3})", persona.Nombre, persona.Apellido, persona.Edad, (int) persona.Sexo);

            conexion.Open();
            comandoSql.ExecuteNonQuery();
            conexion.Close();
            Console.WriteLine("Se agregó con éxito..");

            return retorno;
        }

        public static bool ModificarDB(this Persona persona, int id)
        {
            SqlConnection conexion = new SqlConnection(@"Data Source = LAB5PC23\SQLEXPRESS; Initial Catalog = Personas_DB; Integrated Security = True");

            SqlCommand comando = new SqlCommand();
            comando.CommandText = "UPDATE dbo.personas SET nombre='" + persona.Nombre + "', apellido='" + persona.Apellido + "',edad=" + persona.Edad+ ",sexo = " + (int)persona.Sexo  + " WHERE Id=" + id;
            comando.CommandType = CommandType.Text;
            comando.Connection = conexion;

            conexion.Open();
            comando.ExecuteNonQuery();
            conexion.Close();
            Console.WriteLine("Se ha modificado con exito..");

            return true;
        }

        public static bool BorrarDB(this Persona persona, int id)
        {
            SqlConnection conexion = new SqlConnection(@"Data Source = LAB5PC23\SQLEXPRESS; Initial Catalog = Personas_DB; Integrated Security = True");

            SqlCommand comandoSql = new SqlCommand();
            comandoSql.CommandType = CommandType.Text;
            comandoSql.Connection = conexion;
            comandoSql.CommandText = string.Format("DELETE FROM dbo.personas WHERE id={0}", id);

            conexion.Open();
            comandoSql.ExecuteNonQuery();
            conexion.Close();
            Console.WriteLine("Se Borró con éxito..");
        }
    }
}
