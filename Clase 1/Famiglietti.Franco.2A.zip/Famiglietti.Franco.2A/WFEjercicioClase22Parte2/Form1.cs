﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFEjercicioClase22Parte2
{
    public partial class Form1 : Form
    {
        public ActualizarNombrePorDelegado delegado;

        public Form1()
        {
            InitializeComponent();
            IsMdiContainer = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void TestDelegados_Click(object sender, EventArgs e)
        {
            frmTestDelegados frm = new frmTestDelegados();

            frm.Show(this); //Aca hago que Form1 (this) sea el owner del formulario que abro

            
        }

        private void alumnos_Click(object sender, EventArgs e)
        {
            
        }

        private void datosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDatos datos = new frmDatos();
            datos.Show(this);

            this.delegado += new ActualizarNombrePorDelegado(datos.ActualizarNombrePorDelegado);
            this.delegado.Invoke("probando, probando");
        }
    }
}
