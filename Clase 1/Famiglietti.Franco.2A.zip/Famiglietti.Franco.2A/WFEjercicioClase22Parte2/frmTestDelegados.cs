﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFEjercicioClase22Parte2
{
    public partial class frmTestDelegados : Form
    {
        public frmTestDelegados()
        {
            InitializeComponent();
        }

        private void frmTestDelegados_Load(object sender, EventArgs e)
        {
            ConfigurarOpenSaveFileDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ((Form1)this.Owner).delegado(this.textBox1.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ConfigurarOpenSaveFileDialog()
        {
            //Environment.CurrentDirectory = Environment.GetFolderPath;
        }
    }
}
