﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFEjercicioClase22Parte2
{
    public partial class frmDatos : Form
    {
        public frmDatos()
        {
            InitializeComponent();
        }

        private void frmDatos_Load(object sender, EventArgs e)
        {
            
        }

        public void ActualizarNombrePorDelegado(string nombre)
        {
            this.label1.Text = nombre;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
