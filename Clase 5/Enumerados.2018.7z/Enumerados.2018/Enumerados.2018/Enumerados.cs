﻿public enum MiEnumerado
{
    Enum1,
    Enum2,
    Enum3,
    Enum4,
    Enum5,
    Enum6,
    Enum7,
    Enum8
}